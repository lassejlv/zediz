# [HIGH] Node-supplied WireGuard fields are trusted in peer configs

**File:** [`crates/controlplane/src/agent/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/agent/routes.rs#L46-L413) (lines 46, 103, 410, 413)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `other-config-injection`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

register and heartbeat accept wireguard_public_key and wireguard_listen_port directly from the node and store them on the node row without validating key syntax, control characters, or port range. Private network sync later sends those values to other nodes, where the agent renders peer.public_key directly into wg0.conf. A compromised node can submit malformed or newline-containing key material that poisons WireGuard configuration on peer nodes, causing workspace-wide private-network outage or config injection into other nodes' peer blocks.

## Recommendation

Validate WireGuard public keys with a strict parser or base64/key-length check, reject control characters/newlines, restrict listen_port to 1..65535, and only mark private_network_capable after validation succeeds.

## Revalidation

**Verdict:** true-positive

`register` and `heartbeat` accept `wireguard_public_key` as an arbitrary string and `wireguard_listen_port` as an arbitrary `i32`. There is no parser, base64/key-length check, control-character rejection, or port-range check before storing those values on the node row. The migration/entity shape confirms these are plain text/integer fields without a protective database constraint. `private_network::sync_workspace` later fetches ready private-network-capable nodes and places the stored public key and listen port into peer payloads for other nodes. The agent deserializes that payload and renders `PublicKey = {peer.public_key}` and `Endpoint = ...:{port}` directly into `wg0.conf`. A newline-containing public key can therefore inject additional WireGuard config lines, and malformed keys or invalid ports can break peer configuration. Register triggers a workspace sync immediately when private networking is declared capable, and heartbeat-stored values are used on subsequent syncs. This requires a valid or compromised node token, but it crosses the node trust boundary and can poison peer node network configuration.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
