# [HIGH] Bootstrap tokens can be replayed to mint fresh node tokens

**File:** [`crates/controlplane/src/agent/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/agent/routes.rs#L70-L92) (lines 70, 76, 81, 92)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `auth-bypass`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The register handler verifies only the signed bootstrap token claims, then loads the node by id and mints a new node token. It never compares the presented bootstrap token fingerprint with nodes.bootstrap_token_hash, never requires that hash to be non-null, and ignores the loaded node status. A stolen bootstrap token can therefore be replayed until token expiry, including after the real agent registered and the DB hash was cleared, to overwrite node_token_hash and take over that node's heartbeat. The attacker can then claim commands for that node, including hydrated command payloads containing registry or GitHub credentials.

## Recommendation

Store and consume bootstrap tokens atomically: require nodes.bootstrap_token_hash = fingerprint(req.bootstrap_token), require an expected provisioning/unregistered state, clear the hash in the same conditional UPDATE, and reject if rows_affected is zero.

## Revalidation

**Verdict:** true-positive

Provisioning mints a bootstrap token and stores `tokens::fingerprint(&bootstrap)` in `nodes.bootstrap_token_hash`. The `register` handler verifies only the signed token claims and expiry with `tokens::verify`, then loads `workspace_id, status` by `claims.node_id`. It compares the workspace id but never compares the presented token fingerprint to `bootstrap_token_hash`, never requires that hash to be non-null, and ignores the loaded status. The subsequent update is `WHERE id = $10`, clears `bootstrap_token_hash`, and overwrites `node_token_hash` with a newly minted node token. Therefore a stolen bootstrap token remains replayable until its signed expiry even after the legitimate registration cleared the DB hash. Replaying it invalidates the real agent token and makes the attacker's new node token pass `NodeAuth`, because `NodeAuth` only checks `node_token_hash`. With that token, the attacker can heartbeat as the node and claim pending commands; command hydration injects registry or GitHub secrets for pull/build commands before returning them to the node.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
