# [MEDIUM] Mutable GitHub Action refs can publish compromised agent images

**File:** [`.github/workflows/agent-image.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/agent-image.yml#L17-L48) (lines 17, 18, 19, 21, 23, 26, 28, 32, 34, 42, 47, 48)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-ci-supply-chain`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/agent. Multiple actions are referenced by mutable major tags instead of immutable commit SHAs, including the third-party Blacksmith setup/build actions. If one of those action tags is retargeted or the action maintainer account/repository is compromised, attacker-controlled code can run in this job with package write access or active Docker registry credentials and publish a malicious agent image.

## Recommendation

Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

## Revalidation

**Verdict:** true-positive

The workflow grants `contents: read` and `packages: write`, logs in to GHCR using `${{ secrets.GITHUB_TOKEN }}`, and then pushes `ghcr.io/driftbase/agent`. Every action reference in the job is a mutable tag: `actions/checkout@v4`, `docker/setup-qemu-action@v3`, `useblacksmith/setup-docker-builder@v1`, `docker/login-action@v3`, `docker/metadata-action@v5`, and `useblacksmith/build-push-action@v2`. A compromised or retagged action can run code in the job with the job token permissions, and later steps also have Docker registry credentials available through the runner's Docker config after login. The build-push action is especially sensitive because it directly controls the image build and push operation. The trigger is push to `main` for relevant paths or manual dispatch, so the attack requires a legitimate workflow run plus a compromised mutable action reference rather than arbitrary external input. I read the full workflow and checked current history/status; there is no full-SHA pinning or additional mitigation in the current file. The concrete impact is publication of a malicious agent image under the project GHCR namespace.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
