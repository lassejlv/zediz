# [HIGH] Unpinned SSH deploy action receives production SSH credentials

**File:** [`.github/workflows/deploy.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/deploy.yml#L14-L25) (lines 14, 18, 19, 21, 22, 23, 24, 25)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `other-ci-supply-chain`

## Owners

**Suggested assignee:** `157653362+blacksmith-sh[bot]@users.noreply.github.com` _(via last-committer)_

## Finding

The deploy job passes DEPLOY_SSH_HOST, DEPLOY_SSH_USER, and the private DEPLOY_SSH_KEY directly into appleboy/ssh-action@v1, a mutable major-tag action reference. If that action tag is retargeted or the action repository/maintainer is compromised, attacker-controlled action code can exfiltrate the SSH private key and server coordinates or run arbitrary commands on the deployment host. The job also does not declare restrictive workflow permissions, so the default GITHUB_TOKEN permissions may be available unnecessarily.

## Recommendation

Pin appleboy/ssh-action to a reviewed full commit SHA, set `permissions: {}` for this job if no GitHub token access is needed, and consider protecting deployment secrets with a GitHub Environment requiring review or using short-lived deploy credentials.

## Revalidation

**Verdict:** true-positive

The current workflow still uses `appleboy/ssh-action@v1` and passes `secrets.DEPLOY_SSH_HOST`, `secrets.DEPLOY_SSH_USER`, `secrets.DEPLOY_SSH_KEY`, and the optional port directly into that action. GitHub Actions major-version tags are mutable references, so a retagged or compromised action release would execute attacker-controlled action code in this job. Because the SSH private key is supplied as an action input, malicious action code can read or forward it and can also use the host and username to connect to the deployment target. The workflow is manual-only, which limits triggering to users who can dispatch it, but it does not mitigate malicious code inside the referenced action when the workflow is legitimately run. The job also does not declare restrictive `permissions`, so the effective `GITHUB_TOKEN` scope depends on repository defaults rather than being explicitly minimized. I checked the full file and recent history for the workflow; no pinning, environment protection, or permissions hardening is present in the current checked-in version. The concrete attack is compromise or retargeting of `appleboy/ssh-action@v1`, followed by exfiltration of the SSH key or arbitrary deployment-host commands during the next manual deploy.

## Recent committers (`git log`)

- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
