# [HIGH] Stale nodes can revive retired deployments

**File:** [`crates/controlplane/src/agent/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/agent/routes.rs#L454-L528) (lines 454, 483, 528)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `other-invalid-state-transition`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

deployment_status authorizes a report when deployments.node_id matches the reporting node, even after the deployment was stopped and its allocation was removed. Because stopped rows keep node_id, any node that previously ran a deployment can later report status=running for it. The handler then treats that as entered_running and calls retire_superseded_running, which can stop the currently active deployment for the service and push route changes back to the stale container.

## Recommendation

Enforce a deployment state machine in the UPDATE predicate. For agent reports, require an active allocation or a current non-terminal state owned by the node, reject running reports for stopped/errored deployments, and perform the status update plus side effects in a transaction after checking rows_affected.

## Revalidation

**Verdict:** true-positive

`deployment_status` authorizes a node if `deployments.node_id` matches or if an active allocation exists. Stopped deployments keep their `node_id`; the stopped-status path releases private IPs and deletes allocations, but does not clear `deployments.node_id`. A node that previously owned a deployment can later send a `running` status for that stopped row and still satisfy the authorization predicate through `d.node_id = $2`. The update predicate also permits this and does not require a non-terminal/current state or an active allocation. Because `previous_status` was stopped and the new status is running, `entered_running` becomes true. The handler then calls `retire_superseded_running`, which marks other running deployments for the same service as stopped and deletes their allocations. Route generation also keys off `d.node_id` plus `d.status = 'running'`, so the stale row can affect Caddy route updates for that node. A compromised or stale node token can therefore disrupt the currently active deployment for a service it used to host.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
