# [MEDIUM] Workspace monthly cost cap is configurable but unenforced

**File:** [`crates/controlplane/src/workspaces/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/workspaces/routes.rs#L219-L257) (lines 219, 238, 257)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `expensive-api-abuse`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The API accepts and persists max_monthly_euro with only a non-negative validation, but the paid-resource paths reviewed in this codebase do not enforce it. Scheduler provisioning reads max_nodes, not max_monthly_euro, and volume creation calls the Hetzner API directly without checking the cap. A workspace member who can deploy services or create volumes can therefore drive billable Hetzner usage past the configured cost cap.

## Recommendation

Enforce max_monthly_euro before every paid Hetzner operation, including scheduler provisioning, manual node provisioning, and volume creation. Compute projected monthly cost for current nodes and volumes, reject or pause work that exceeds the cap, and make the UI reflect the same enforcement model.

## Revalidation

**Verdict:** true-positive

The current update route accepts max_monthly_euro, only rejects negative values, and persists it to workspaces. A tree-wide search shows max_monthly_euro is otherwise only present in the workspace API shape, entity metadata, and migration, not in paid Hetzner operations. Scheduler provisioning reads hetzner_location, max_nodes, and scheduler_paused_until, then provisions after only a node-count cap. Manual node provisioning likewise selects max_nodes but not max_monthly_euro before calling the Hetzner provisioner. Volume creation authorizes a workspace member and then calls HetznerClient.create_volume with user-controlled size up to 10240 GB without budget projection. A workspace member can therefore create billable volumes, and a member can deploy resource-hungry services that trigger provisioning, without the configured euro cap stopping provider calls. The only mitigation I found is max_nodes, which limits node count but not node class cost and does not cover volumes. The current git history for the file has no later patch adding enforcement, so the finding remains real.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
