# [HIGH_BUG] Node delete can drop Driftbase state while leaving a live Hetzner VM

**File:** [`crates/controlplane/src/nodes/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/nodes/routes.rs#L381-L404) (lines 381, 393, 404)
**Project:** driftbase
**Severity:** HIGH_BUG  •  **Confidence:** high  •  **Slug:** `other-orphaned-cloud-resource`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The delete route decides to call Hetzner only when the node is not `terminated` and has a server id. If no Hetzner credential is available, it falls through and deletes the node row even though the VM may still be live. A second failure path exists after `hetzner_provisioner::terminate` marks the row `terminated` before calling Hetzner: if the provider delete fails, a retry skips Hetzner because status is now `terminated` and deletes the row. Both paths can orphan a billable VM outside Driftbase management.

## Recommendation

Do not delete a Hetzner node row while `hetzner_server_id` is present unless provider deletion has succeeded or returned not-found. Keep a retryable state for failed termination, retry tombstones with server ids, and return an error when credentials are unavailable instead of dropping the row.

## Revalidation

**Verdict:** true-positive

The delete route is admin-gated and workspace-scoped, so the issue is not authorization but provider-state handling. It decides to call Hetzner only when provider is hetzner, status is not terminated, and hetzner_server_id is present. If first_hetzner_token returns None, the code falls through and deletes the node row even though the provider/server-id fields indicate a potentially live VM. That missing-token state is reachable because admins can delete credentials. The second path is also present: hetzner_provisioner::terminate sets node status to terminated before calling delete_server, then returns an error if provider deletion fails. A retry of the route sees status terminated, skips the Hetzner call, and deletes the row, losing the only Driftbase pointer to the billable VM. Hetzner 404 idempotency only helps after a delete call is actually made; it does not mitigate the missing-token or tombstone retry paths. The current git history has no later patch changing this flow.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
