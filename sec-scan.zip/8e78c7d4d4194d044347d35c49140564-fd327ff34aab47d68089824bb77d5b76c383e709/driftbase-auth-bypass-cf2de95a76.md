# [HIGH] Mounted agent registration route accepts replayed bootstrap tokens

**File:** [`crates/controlplane/src/main.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/main.rs#L138-L146) (lines 138, 146)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `auth-bypass`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

`main.rs` mounts `agent::routes::router()` under `/api/v1`. The merged `/agent/register` handler verifies the bootstrap token signature, but the handler in `crates/controlplane/src/agent/routes.rs` only loads the node by claimed id and workspace, never compares `tokens::fingerprint(req.bootstrap_token)` with `nodes.bootstrap_token_hash` and never requires `status = 'provisioning'`. Because the same handler clears `bootstrap_token_hash` without requiring it in the `WHERE` clause, any leaked bootstrap token can be replayed within its TTL to mint a fresh long-lived node token and replace the legitimate node token.

## Recommendation

Make registration an atomic one-shot exchange: `UPDATE nodes ... WHERE id = $node_id AND workspace_id = $workspace_id AND status = 'provisioning' AND bootstrap_token_hash = $fingerprint RETURNING ...`. Reject when no row is updated, then clear the bootstrap hash and store the node token hash in that same statement or transaction.

## Revalidation

**Verdict:** true-positive

`main.rs` merges `agent::routes::router()` into the `/api/v1` API, and `/agent/register` is intentionally unauthenticated except for the bootstrap token in the JSON body. The registration handler verifies the token signature, kind, and TTL with `tokens::verify`, then selects `workspace_id, status` from `nodes` by the claimed node id. It compares the row workspace id to the token claim, but it never checks `nodes.bootstrap_token_hash` against `tokens::fingerprint(req.bootstrap_token)`. It also ignores the node `status`, so a node that is already `ready` can still be registered again while the signed bootstrap token remains within its TTL. The provisioner stores `bootstrap_token_hash` when creating a provisioning node, which shows the intended one-shot database binding exists but is not enforced by registration. The update uses only `WHERE id = $10`, then replaces `node_token_hash` and clears `bootstrap_token_hash`, so a replayed leaked bootstrap token can mint a fresh long-lived node token and invalidate the legitimate one. Current git history and source do not show a later atomic one-shot patch, so the finding remains real.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
