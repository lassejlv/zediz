# [HIGH] Project board fetch exposes service environment secrets to viewers

**File:** [`web/src/routes/w.$workspaceSlug.projects.$projectSlug.index.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/routes/w.$workspaceSlug.projects.$projectSlug.index.tsx#L23) (lines 23)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `acl-check`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The project board calls `servicesQuery` for every workspace member who can open the project. That API response is typed as `ServiceSummary`, which includes `env_vars`; the backend list handler only checks workspace membership with `membership::resolve` and serializes `ServiceSummary.env_vars` in the list response. A read-only workspace viewer can therefore open this page or call the same endpoint and recover plaintext service environment values such as template-generated database passwords or user-supplied API keys, even though the board itself only needs non-secret service metadata.

## Recommendation

Return a non-secret service list shape for project board usage that omits `env_vars` and credential IDs. Gate any endpoint that returns plaintext environment variables behind an explicit role check, or avoid returning stored secret values after creation.

## Revalidation

**Verdict:** true-positive

The project board always calls `servicesQuery(workspaceSlug, projectSlug)` once the route is opened. That query returns `ServiceSummary[]`, and the TypeScript `ServiceSummary` includes `env_vars`. On the backend, the `list` handler in `services/routes.rs` only calls `membership::resolve`, so viewers are authorized. It selects `SERVICE_COLUMNS`, which includes `env_vars`, and serializes the values without redaction. The board does not render those values in `ServiceNode`, but they are still delivered to the browser and cached by React Query. A read-only workspace viewer can also call the same `/services` endpoint directly. There is no later filtering layer or response-shaping mitigation.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-04-22)
