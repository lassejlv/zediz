# [HIGH] Read-only workspace members can retrieve service environment secrets

**File:** [`web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx#L64-L259) (lines 64, 259)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `acl-check`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The route fetches the full ServiceSummary for any workspace member and renders the Settings tab without a role gate. Tracing the backend shows ServiceSummary serializes env_vars, and the service show/list handlers only call membership::resolve without requiring a write/admin role before returning those values. ServiceSettingsTab then initializes rows directly from service.env_vars and renders password inputs with reveal controls. A workspace viewer can visit the service settings page or call the same service detail API and read application secrets such as database URLs, API keys, and generated passwords despite being read-only.

## Recommendation

Split secret env values out of the general ServiceSummary response. Require at least member/admin role for an explicit service settings/env endpoint, or return redacted placeholders to viewers. Add backend authorization tests for viewer access to service env vars.

## Revalidation

**Verdict:** true-positive

The service page calls `serviceQuery(workspaceSlug, projectSlug, serviceSlug)` for any authenticated user who can load the route, and the Settings tab is present for all roles. The backend `show` handler in `crates/controlplane/src/services/routes.rs` only calls `membership::resolve`, which accepts viewers, and does not call `membership::require`. That handler selects `SERVICE_COLUMNS`, which includes `env_vars`, then serializes them through `ServiceSummary`. The frontend `ServiceSummary` type also includes `env_vars`, and `ServiceSettingsTab` initializes rows directly from `service.env_vars`. `canManage` disables editing and saving, but it does not remove the values from the response, and the reveal control is still enough UI exposure on top of the raw API response. A workspace viewer can therefore call the service detail API or open the page and recover plaintext environment values. No framework-level middleware narrows this because the request is a valid authenticated same-workspace viewer request.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
