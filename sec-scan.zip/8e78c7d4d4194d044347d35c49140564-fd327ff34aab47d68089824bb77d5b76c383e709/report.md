# Vulnerability Scan Report

| Field | Value |
|-------|-------|
| Project | driftbase |
| Date | 2026-05-12T13:31:30.387Z |
| Files tracked | 57 |
| Files analyzed | 57 |
| Total findings | 30 |

## Summary

| Severity | Count |
|----------|-------|
| CRITICAL | 0 |
| HIGH | 13 |
| MEDIUM | 9 |
| HIGH_BUG | 5 |
| BUG | 3 |

## HIGH (13)

### Unpinned SSH deploy action receives production SSH credentials

- **File:** `.github/workflows/deploy.yml`
- **Recent committers:** blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>, Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 14, 18, 19, 21, 22, 23, 24, 25
- **Slug:** other-ci-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The current workflow still uses `appleboy/ssh-action@v1` and passes `secrets.DEPLOY_SSH_HOST`, `secrets.DEPLOY_SSH_USER`, `secrets.DEPLOY_SSH_KEY`, and the optional port directly into that action. GitHub Actions major-version tags are mutable references, so a retagged or compromised action release would execute attacker-controlled action code in this job. Because the SSH private key is supplied as an action input, malicious action code can read or forward it and can also use the host and username to connect to the deployment target. The workflow is manual-only, which limits triggering to users who can dispatch it, but it does not mitigate malicious code inside the referenced action when the workflow is legitimately run. The job also does not declare restrictive `permissions`, so the effective `GITHUB_TOKEN` scope depends on repository defaults rather than being explicitly minimized. I checked the full file and recent history for the workflow; no pinning, environment protection, or permissions hardening is present in the current checked-in version. The concrete attack is compromise or retargeting of `appleboy/ssh-action@v1`, followed by exfiltration of the SSH key or arbitrary deployment-host commands during the next manual deploy.

The deploy job passes DEPLOY_SSH_HOST, DEPLOY_SSH_USER, and the private DEPLOY_SSH_KEY directly into appleboy/ssh-action@v1, a mutable major-tag action reference. If that action tag is retargeted or the action repository/maintainer is compromised, attacker-controlled action code can exfiltrate the SSH private key and server coordinates or run arbitrary commands on the deployment host. The job also does not declare restrictive workflow permissions, so the default GITHUB_TOKEN permissions may be available unnecessarily.

**Recommendation:** Pin appleboy/ssh-action to a reviewed full commit SHA, set `permissions: {}` for this job if no GitHub token access is needed, and consider protecting deployment secrets with a GitHub Environment requiring review or using short-lived deploy credentials.

---

### Bootstrap tokens can be replayed to mint fresh node tokens

- **File:** `crates/controlplane/src/agent/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 70, 76, 81, 92
- **Slug:** auth-bypass
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** Provisioning mints a bootstrap token and stores `tokens::fingerprint(&bootstrap)` in `nodes.bootstrap_token_hash`. The `register` handler verifies only the signed token claims and expiry with `tokens::verify`, then loads `workspace_id, status` by `claims.node_id`. It compares the workspace id but never compares the presented token fingerprint to `bootstrap_token_hash`, never requires that hash to be non-null, and ignores the loaded status. The subsequent update is `WHERE id = $10`, clears `bootstrap_token_hash`, and overwrites `node_token_hash` with a newly minted node token. Therefore a stolen bootstrap token remains replayable until its signed expiry even after the legitimate registration cleared the DB hash. Replaying it invalidates the real agent token and makes the attacker's new node token pass `NodeAuth`, because `NodeAuth` only checks `node_token_hash`. With that token, the attacker can heartbeat as the node and claim pending commands; command hydration injects registry or GitHub secrets for pull/build commands before returning them to the node.

The register handler verifies only the signed bootstrap token claims, then loads the node by id and mints a new node token. It never compares the presented bootstrap token fingerprint with nodes.bootstrap_token_hash, never requires that hash to be non-null, and ignores the loaded node status. A stolen bootstrap token can therefore be replayed until token expiry, including after the real agent registered and the DB hash was cleared, to overwrite node_token_hash and take over that node's heartbeat. The attacker can then claim commands for that node, including hydrated command payloads containing registry or GitHub credentials.

**Recommendation:** Store and consume bootstrap tokens atomically: require nodes.bootstrap_token_hash = fingerprint(req.bootstrap_token), require an expected provisioning/unregistered state, clear the hash in the same conditional UPDATE, and reject if rows_affected is zero.

---

### Stale nodes can revive retired deployments

- **File:** `crates/controlplane/src/agent/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 454, 483, 528
- **Slug:** other-invalid-state-transition
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `deployment_status` authorizes a node if `deployments.node_id` matches or if an active allocation exists. Stopped deployments keep their `node_id`; the stopped-status path releases private IPs and deletes allocations, but does not clear `deployments.node_id`. A node that previously owned a deployment can later send a `running` status for that stopped row and still satisfy the authorization predicate through `d.node_id = $2`. The update predicate also permits this and does not require a non-terminal/current state or an active allocation. Because `previous_status` was stopped and the new status is running, `entered_running` becomes true. The handler then calls `retire_superseded_running`, which marks other running deployments for the same service as stopped and deletes their allocations. Route generation also keys off `d.node_id` plus `d.status = 'running'`, so the stale row can affect Caddy route updates for that node. A compromised or stale node token can therefore disrupt the currently active deployment for a service it used to host.

deployment_status authorizes a report when deployments.node_id matches the reporting node, even after the deployment was stopped and its allocation was removed. Because stopped rows keep node_id, any node that previously ran a deployment can later report status=running for it. The handler then treats that as entered_running and calls retire_superseded_running, which can stop the currently active deployment for the service and push route changes back to the stale container.

**Recommendation:** Enforce a deployment state machine in the UPDATE predicate. For agent reports, require an active allocation or a current non-terminal state owned by the node, reject running reports for stopped/errored deployments, and perform the status update plus side effects in a transaction after checking rows_affected.

---

### Node-supplied WireGuard fields are trusted in peer configs

- **File:** `crates/controlplane/src/agent/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 46, 103, 410, 413
- **Slug:** other-config-injection
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `register` and `heartbeat` accept `wireguard_public_key` as an arbitrary string and `wireguard_listen_port` as an arbitrary `i32`. There is no parser, base64/key-length check, control-character rejection, or port-range check before storing those values on the node row. The migration/entity shape confirms these are plain text/integer fields without a protective database constraint. `private_network::sync_workspace` later fetches ready private-network-capable nodes and places the stored public key and listen port into peer payloads for other nodes. The agent deserializes that payload and renders `PublicKey = {peer.public_key}` and `Endpoint = ...:{port}` directly into `wg0.conf`. A newline-containing public key can therefore inject additional WireGuard config lines, and malformed keys or invalid ports can break peer configuration. Register triggers a workspace sync immediately when private networking is declared capable, and heartbeat-stored values are used on subsequent syncs. This requires a valid or compromised node token, but it crosses the node trust boundary and can poison peer node network configuration.

register and heartbeat accept wireguard_public_key and wireguard_listen_port directly from the node and store them on the node row without validating key syntax, control characters, or port range. Private network sync later sends those values to other nodes, where the agent renders peer.public_key directly into wg0.conf. A compromised node can submit malformed or newline-containing key material that poisons WireGuard configuration on peer nodes, causing workspace-wide private-network outage or config injection into other nodes' peer blocks.

**Recommendation:** Validate WireGuard public keys with a strict parser or base64/key-length check, reject control characters/newlines, restrict listen_port to 1..65535, and only mark private_network_capable after validation succeeds.

---

### Fresh instances can be claimed by the first public signup

- **File:** `crates/controlplane/src/auth/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 104, 117, 152
- **Slug:** auth-bypass
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `/auth/signup` is public by design and takes no `AuthUser` or setup credential. The handler validates email/password and applies only per-email rate limiting, then takes an advisory lock and counts rows in `users`. If the count is zero, it inserts the new account with `status = 'approved'` and `is_platform_admin = true`. It then treats `is_first_user` as active and immediately creates a session cookie. There is no setup token, local-only restriction, deployment flag, or out-of-band installer proof in the route or surrounding router. The global router mounts `/api/v1/auth/signup` publicly, and CORS settings do not mitigate a direct network request. If a fresh control plane is reachable before the operator creates the first account, an unauthenticated attacker can become the platform admin and then create/manage workspaces.

/auth/signup is public and promotes the first account in an empty users table to approved platform admin, then immediately issues a session. There is no setup token, local-only restriction, or other installer proof. If the control plane is reachable before the real operator creates the first account, an unauthenticated attacker can become the platform admin and bootstrap their own workspace.

**Recommendation:** Gate first-admin creation behind a one-time setup secret or out-of-band CLI/admin creation path. Keep public signup accounts pending until an already-established platform admin approves them.

---

### Workspace viewers can stop and restart deployments

- **File:** `crates/controlplane/src/deployments/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 37, 40, 77, 91, 110, 120
- **Slug:** acl-check
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The `/deployments/:id/stop` and `/deployments/:id/restart` routes are mounted under `/api/v1` and require only `AuthUser`, which validates a normal user session. Both handlers then call `deployments::authorize`, whose implementation only joins `workspace_members` for the user and deployment and does not parse or require any minimum role. The helper comment explicitly says it enforces at least viewer access, and `membership::Role` ranks viewer as a valid workspace role. After that weak check, `stop` enqueues a Stop command or directly marks the deployment stopped and deletes allocations. `restart` enqueues Remove, resets the deployment to pending, clears node/private state, deletes allocations, clears `scheduler_paused_until`, and nudges the scheduler. The frontend may hide management controls for viewers, but the backend route itself accepts direct POSTs. A viewer who can see deployment IDs through workspace-readable service/deployment endpoints can disrupt running workloads, so this is exploitable as reported.

`stop` and `restart` only call `deployments::authorize`, which the helper documents and implements as an at-least-viewer workspace membership check. These handlers then enqueue Stop/Remove commands, mutate deployment state, delete allocations, nudge scheduling, and in `restart` clear `scheduler_paused_until`. A read-only workspace viewer can therefore disrupt running services and trigger redeployment/provisioning actions.

**Recommendation:** Resolve the deployment's workspace and require an appropriate role, likely `Role::Member` or `Role::Admin`, before mutating deployment state. Consider adding a dedicated `authorize_member`/`authorize_admin` helper for deployment actions.

---

### Mounted agent registration route accepts replayed bootstrap tokens

- **File:** `crates/controlplane/src/main.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 138, 146
- **Slug:** auth-bypass
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `main.rs` merges `agent::routes::router()` into the `/api/v1` API, and `/agent/register` is intentionally unauthenticated except for the bootstrap token in the JSON body. The registration handler verifies the token signature, kind, and TTL with `tokens::verify`, then selects `workspace_id, status` from `nodes` by the claimed node id. It compares the row workspace id to the token claim, but it never checks `nodes.bootstrap_token_hash` against `tokens::fingerprint(req.bootstrap_token)`. It also ignores the node `status`, so a node that is already `ready` can still be registered again while the signed bootstrap token remains within its TTL. The provisioner stores `bootstrap_token_hash` when creating a provisioning node, which shows the intended one-shot database binding exists but is not enforced by registration. The update uses only `WHERE id = $10`, then replaces `node_token_hash` and clears `bootstrap_token_hash`, so a replayed leaked bootstrap token can mint a fresh long-lived node token and invalidate the legitimate one. Current git history and source do not show a later atomic one-shot patch, so the finding remains real.

`main.rs` mounts `agent::routes::router()` under `/api/v1`. The merged `/agent/register` handler verifies the bootstrap token signature, but the handler in `crates/controlplane/src/agent/routes.rs` only loads the node by claimed id and workspace, never compares `tokens::fingerprint(req.bootstrap_token)` with `nodes.bootstrap_token_hash` and never requires `status = 'provisioning'`. Because the same handler clears `bootstrap_token_hash` without requiring it in the `WHERE` clause, any leaked bootstrap token can be replayed within its TTL to mint a fresh long-lived node token and replace the legitimate node token.

**Recommendation:** Make registration an atomic one-shot exchange: `UPDATE nodes ... WHERE id = $node_id AND workspace_id = $workspace_id AND status = 'provisioning' AND bootstrap_token_hash = $fingerprint RETURNING ...`. Reject when no row is updated, then clear the bootstrap hash and store the node token hash in that same statement or transaction.

---

### Members can exfiltrate GitHub PATs through arbitrary git remotes

- **File:** `crates/controlplane/src/services/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 67, 319, 340, 449, 502, 508, 573
- **Slug:** secrets-exposure
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** Service create and update require only `Role::Member`, and the git-source fields accept `git_repo` plus `github_credential_id` directly from request JSON. The update path does not validate that a supplied credential is a GitHub PAT, that it is intended for the repository, or that the repository is on GitHub; it only stores the field. `ServiceSummary` includes `github_credential_id`, and service list/show are available to any workspace member, so a non-admin member can learn the PAT credential id from an existing PAT-backed service. The scheduler later validates only that the credential exists in the same workspace and has kind `github_pat`, then the agent command hydration replaces the credential id with the plaintext PAT. On the agent, `git clone` installs a credential helper that returns `x-access-token` and `$DRIFTBASE_GIT_TOKEN` for credential prompts, and the only host-related guard is refusing plain `http://`. An attacker with member access can point an existing git service at an attacker-controlled HTTPS remote and deploy; the remote can challenge for credentials and receive the PAT over HTTPS. The same-workspace scope prevents cross-tenant credential theft, but it does not prevent member-level misuse of an admin-added PAT.

The service create/update paths accept both an arbitrary git_repo and a github_credential_id from request JSON while requiring only Role::Member. The response model also exposes github_credential_id, so a non-admin member can learn a PAT credential ID from an existing service, update that service to point git_repo at an attacker-controlled HTTPS remote, and deploy. Downstream code validates only that the credential is a github_pat in the same workspace, then hydrates the PAT into the agent build payload; the agent's git credential helper supplies that PAT for any HTTPS clone URL and only refuses plain http://. This turns deploy permission into plaintext GitHub PAT exfiltration.

**Recommendation:** Validate credential use at create/update time and bind GitHub PAT credentials to allowed GitHub hosts/repos before deployment. Do not expose credential IDs to non-admins, require admin approval or an explicit usable-by-members policy for PAT-backed builds, and scope the git credential helper to the allowed GitHub origin instead of any HTTPS URL.

---

### Viewer role can read service environment secrets

- **File:** `crates/controlplane/src/services/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 55, 164, 393
- **Slug:** other-info-disclosure
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The service list and show handlers call `membership::resolve` but never call `membership::require`, so viewers are authorized for both endpoints. `SERVICE_COLUMNS` includes `env_vars`, `ServiceRow` reads it as JSON, and `ServiceSummary` serializes it as `pub env_vars: EnvVars` without role-based redaction. There is no alternate response type for viewers and no masking step based on `ctx.role`. These environment variables are user-controlled runtime secrets and templates include generated database passwords and database URLs, so a read-only viewer can receive high-value secret material. The separate variable reference endpoint mostly returns keys and expressions, but the main service summary returns full values. The UI disabling edits for viewers is not a backend mitigation because the raw API response already contains the secrets. I would rate this high rather than medium because it is a direct confidentiality break of application secrets for the lowest workspace role.

ServiceSummary serializes env_vars, and both list and show only call membership::resolve, which allows any workspace role including viewer. A read-only invited viewer can therefore GET the service list or a specific service and receive full environment variable values, including generated database passwords and connection strings stored as service env vars. The UI role text describes viewers as read-only, but read-only access should not imply access to secret material.

**Recommendation:** Split safe service metadata from sensitive configuration. Return env var keys or masked values to viewers, and require at least Role::Member or Role::Admin for endpoints that return full env var values.

---

### Read-only workspace viewers can receive service environment secrets

- **File:** `web/src/lib/types.ts`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 121
- **Slug:** acl-check
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `web/src/lib/types.ts` defines `ServiceSummary.env_vars` as a raw `Record<string, string>`, which matches the backend contract rather than a redacted or key-only representation. The frontend service queries fetch `ServiceSummary` from the list/show endpoints, and those backend endpoints authorize viewers via `membership::resolve` only. The service page computes `canManage` from `canWrite`, so viewers cannot submit edits through normal UI controls, but the data is already loaded into the page. `ServiceSettingsTab` initializes its environment rows directly from `service.env_vars`; the value input is disabled for viewers, but the reveal button itself is not disabled and the network response contains the plaintext values regardless. This file is not the root cause by itself, but it confirms the client-side API model expects full secret values for all consumers of `ServiceSummary`. A viewer can therefore receive generated Postgres passwords, connection strings, API tokens, or other environment secrets through the normal service API response.

ServiceSummary includes raw env_vars in the frontend API type at line 121. The backend ServiceSummary also serializes env_vars, and both service list/show routes only call membership::resolve, not membership::require with a write/admin role, before returning those summaries. The UI explicitly treats the viewer role as read-only, but the service settings view initializes its environment rows directly from service.env_vars and even lets the reveal button toggle password fields. A workspace viewer can therefore request /api/v1/workspaces/{slug}/projects/{project}/services or a service detail endpoint and recover container environment values such as generated Postgres passwords, database URLs, API tokens, or other application secrets.

**Recommendation:** Do not include env_vars in the general ServiceSummary returned to all workspace members. Return redacted values or only keys for viewer/read-only responses, and expose plaintext environment values only through a dedicated endpoint guarded by at least Role::Member or preferably Role::Admin. Also disable or remove the reveal control for users who are not allowed to view secrets.

---

### Read-only workspace members can retrieve service environment secrets

- **File:** `web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 64, 259
- **Slug:** acl-check
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The service page calls `serviceQuery(workspaceSlug, projectSlug, serviceSlug)` for any authenticated user who can load the route, and the Settings tab is present for all roles. The backend `show` handler in `crates/controlplane/src/services/routes.rs` only calls `membership::resolve`, which accepts viewers, and does not call `membership::require`. That handler selects `SERVICE_COLUMNS`, which includes `env_vars`, then serializes them through `ServiceSummary`. The frontend `ServiceSummary` type also includes `env_vars`, and `ServiceSettingsTab` initializes rows directly from `service.env_vars`. `canManage` disables editing and saving, but it does not remove the values from the response, and the reveal control is still enough UI exposure on top of the raw API response. A workspace viewer can therefore call the service detail API or open the page and recover plaintext environment values. No framework-level middleware narrows this because the request is a valid authenticated same-workspace viewer request.

The route fetches the full ServiceSummary for any workspace member and renders the Settings tab without a role gate. Tracing the backend shows ServiceSummary serializes env_vars, and the service show/list handlers only call membership::resolve without requiring a write/admin role before returning those values. ServiceSettingsTab then initializes rows directly from service.env_vars and renders password inputs with reveal controls. A workspace viewer can visit the service settings page or call the same service detail API and read application secrets such as database URLs, API keys, and generated passwords despite being read-only.

**Recommendation:** Split secret env values out of the general ServiceSummary response. Require at least member/admin role for an explicit service settings/env endpoint, or return redacted placeholders to viewers. Add backend authorization tests for viewer access to service env vars.

---

### Viewers can stop or restart deployments by bypassing client-side controls

- **File:** `web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 72, 73, 75, 181, 182, 206, 207
- **Slug:** acl-check
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The page hides Stop and Restart behind `canWrite`, but the mutation hooks call `/deployments/:id/stop` and `/deployments/:id/restart` directly with only a deployment id. A viewer can obtain deployment ids because `list_deployments` for a service only requires `membership::resolve`. The backend `stop` and `restart` handlers call `deployments::authorize`, and that helper only verifies that the caller has any `workspace_members` row. It fetches the role but never parses or enforces `Role::Member`. The `stop` handler enqueues a stop command or marks an unplaced deployment stopped, while `restart` enqueues removal, resets the row to pending, deletes allocations, and nudges the scheduler. Because the server lacks the write-role check, a viewer can craft the POST requests even though the UI hides the buttons. This is an authorization bug with concrete availability impact.

The page hides Stop/Restart behind canWrite, but the mutation hooks call /deployments/:id/stop and /deployments/:id/restart directly with only a deployment id. Tracing those backend handlers shows both call deployments::authorize, whose query only checks that the caller is a workspace member; it does not require Role::Member or higher. A read-only viewer can obtain deployment ids from the allowed deployment list and POST to these endpoints to stop or restart workloads, causing service disruption.

**Recommendation:** Enforce write authorization server-side for deployment stop/restart, for example with an authorize_member/authorize_write helper that checks the workspace role is at least Member. Keep the UI gate, but treat it only as presentation. Add regression tests for viewer denial on stop and restart.

---

### Project board fetch exposes service environment secrets to viewers

- **File:** `web/src/routes/w.$workspaceSlug.projects.$projectSlug.index.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 23
- **Slug:** acl-check
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The project board always calls `servicesQuery(workspaceSlug, projectSlug)` once the route is opened. That query returns `ServiceSummary[]`, and the TypeScript `ServiceSummary` includes `env_vars`. On the backend, the `list` handler in `services/routes.rs` only calls `membership::resolve`, so viewers are authorized. It selects `SERVICE_COLUMNS`, which includes `env_vars`, and serializes the values without redaction. The board does not render those values in `ServiceNode`, but they are still delivered to the browser and cached by React Query. A read-only workspace viewer can also call the same `/services` endpoint directly. There is no later filtering layer or response-shaping mitigation.

The project board calls `servicesQuery` for every workspace member who can open the project. That API response is typed as `ServiceSummary`, which includes `env_vars`; the backend list handler only checks workspace membership with `membership::resolve` and serializes `ServiceSummary.env_vars` in the list response. A read-only workspace viewer can therefore open this page or call the same endpoint and recover plaintext service environment values such as template-generated database passwords or user-supplied API keys, even though the board itself only needs non-secret service metadata.

**Recommendation:** Return a non-secret service list shape for project board usage that omits `env_vars` and credential IDs. Gate any endpoint that returns plaintext environment variables behind an explicit role check, or avoid returning stored secret values after creation.

---

## MEDIUM (9)

### Mutable GitHub Action refs can publish compromised agent images

- **File:** `.github/workflows/agent-image.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 17, 18, 19, 21, 23, 26, 28, 32, 34, 42, 47, 48
- **Slug:** other-ci-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The workflow grants `contents: read` and `packages: write`, logs in to GHCR using `${{ secrets.GITHUB_TOKEN }}`, and then pushes `ghcr.io/driftbase/agent`. Every action reference in the job is a mutable tag: `actions/checkout@v4`, `docker/setup-qemu-action@v3`, `useblacksmith/setup-docker-builder@v1`, `docker/login-action@v3`, `docker/metadata-action@v5`, and `useblacksmith/build-push-action@v2`. A compromised or retagged action can run code in the job with the job token permissions, and later steps also have Docker registry credentials available through the runner's Docker config after login. The build-push action is especially sensitive because it directly controls the image build and push operation. The trigger is push to `main` for relevant paths or manual dispatch, so the attack requires a legitimate workflow run plus a compromised mutable action reference rather than arbitrary external input. I read the full workflow and checked current history/status; there is no full-SHA pinning or additional mitigation in the current file. The concrete impact is publication of a malicious agent image under the project GHCR namespace.

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/agent. Multiple actions are referenced by mutable major tags instead of immutable commit SHAs, including the third-party Blacksmith setup/build actions. If one of those action tags is retargeted or the action maintainer account/repository is compromised, attacker-controlled code can run in this job with package write access or active Docker registry credentials and publish a malicious agent image.

**Recommendation:** Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

---

### Agent image build executes an unpinned remote installer

- **File:** `.github/workflows/agent-image.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 42, 45, 47
- **Slug:** other-build-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The agent image workflow builds with `file: Dockerfile.agent` and `push: true`, so the Dockerfile contents are part of the trusted published agent image path. In `Dockerfile.agent`, the runtime stage runs `curl -fsSL https://railpack.com/install.sh | bash -s -- -y -b /usr/local/bin` without a version pin, checksum, signature verification, or vendored artifact. That means the build executes whatever shell script the remote endpoint serves at build time. If the endpoint, CDN, DNS path, or upstream release process is compromised, attacker-controlled code runs during the image build and can modify the produced agent image before it is pushed to GHCR. This is not mitigated by Docker layer isolation because the script runs inside the build stage that becomes the runtime image containing `/usr/local/bin` contents. I also checked the release Dockerfile path separately; `docker/agent.Dockerfile` does not contain this installer, but this finding targets the branch image workflow, which still uses root `Dockerfile.agent`. The concrete attack is upstream installer compromise leading to a backdoored published `ghcr.io/driftbase/agent` image.

This workflow publishes the image built from Dockerfile.agent. That Dockerfile runs `curl -fsSL https://railpack.com/install.sh | bash` during the build without a version pin, checksum, or signature verification. A compromise of the installer endpoint or upstream distribution path would execute attacker-controlled code during the trusted image build and could backdoor the published agent image.

**Recommendation:** Replace the curl-to-shell installer with a pinned release artifact verified by checksum/signature, or vendor a known-good binary into the build process.

---

### Mutable GitHub Action refs can publish compromised control plane images

- **File:** `.github/workflows/controlplane-image.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 17, 18, 19, 21, 23, 26, 28, 32, 34, 42, 47, 48
- **Slug:** other-ci-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The control plane image workflow grants `packages: write`, logs in to GHCR with `${{ secrets.GITHUB_TOKEN }}`, and pushes `ghcr.io/driftbase/controlplane`. The job uses only mutable action refs, including the third-party Blacksmith setup and build-push actions. Any compromised or retagged referenced action can execute code in this job with package publishing permissions, and after the login step later action code can use the active Docker registry credentials. The vulnerable sink is the final `useblacksmith/build-push-action@v2` step with `push: true`, which controls the published multi-architecture image. The workflow is limited to pushes on `main` affecting relevant files or manual dispatch, but that only limits when the compromised action code runs. I read the complete workflow and checked recent history/status; the current version has not been patched with commit SHA pins. The concrete attack is action supply-chain compromise resulting in a malicious control plane image being pushed under the Driftbase GHCR namespace.

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/controlplane. The actions are referenced by mutable major tags rather than immutable commit SHAs, including third-party Blacksmith actions. If any referenced action tag is retargeted or the action repository is compromised, attacker-controlled code can run with package write access or Docker registry credentials and publish a malicious control plane image.

**Recommendation:** Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

---

### Mutable release actions run with release and package publishing privileges

- **File:** `.github/workflows/release.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 8, 9, 23, 24, 32, 42, 51, 52, 53, 55, 56, 58, 59, 63, 65, 75
- **Slug:** other-ci-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The release workflow has top-level `contents: write`, so the agent release job's mutable actions run in a job that can create or modify releases. That job uses mutable refs for `actions/checkout@v4`, `dtolnay/rust-toolchain@stable`, `Swatinem/rust-cache@v2`, and `softprops/action-gh-release@v2`, then uploads release artifacts. The images job narrows contents to read but grants `packages: write`, logs in to GHCR, and uses mutable Docker and Blacksmith actions before pushing release images. A compromised or retagged action in either job can alter uploaded binaries, create or modify release assets, or publish malicious images depending on which job it runs in. The trigger is tag push matching `v*`, so exploitation requires a release workflow run plus action supply-chain compromise. I read the entire workflow and checked current history/status; there is no full-SHA pinning or permission isolation that would prevent this. The concrete attack is a malicious action replacing release binaries or pushing compromised `controlplane` and `agent` images during a tagged release.

The release workflow uses mutable action refs while granting contents: write for release creation and packages: write for image publishing. Third-party actions such as dtolnay/rust-toolchain@stable, Swatinem/rust-cache@v2, softprops/action-gh-release@v2, and useblacksmith/*@v1/v2 can execute in jobs that publish release artifacts or container images. A compromised or retagged action could replace release binaries or publish malicious GHCR images under the project namespace.

**Recommendation:** Pin every action to a full commit SHA and review the pinned SHAs before updates. Split permissions by job and step where possible so actions that do not need write access do not receive it.

---

### Mutable GitHub Action refs can publish compromised web images

- **File:** `.github/workflows/web-image.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 16, 17, 18, 20, 22, 25, 27, 31, 33, 41, 46, 47
- **Slug:** other-ci-supply-chain
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The web image workflow grants `packages: write`, logs in to GHCR using `${{ secrets.GITHUB_TOKEN }}`, and pushes `ghcr.io/driftbase/web`. It references `actions/checkout@v4`, `docker/setup-qemu-action@v3`, `useblacksmith/setup-docker-builder@v1`, `docker/login-action@v3`, `docker/metadata-action@v5`, and `useblacksmith/build-push-action@v2` by mutable tags rather than full commit SHAs. A compromised or retagged action can execute code in the workflow with package write permission, and after the login step can use the active Docker registry credentials. The final Blacksmith build-push step controls the image content and performs the push with `push: true`. The trigger is limited to `main` pushes affecting web image inputs or manual dispatch, but that still leaves the supply-chain path exploitable on legitimate runs. I read the complete workflow and checked current history/status; there is no pinning or alternate mitigation in the current file. The concrete attack is publishing a malicious web image under the project GHCR namespace through a compromised mutable action.

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/web. The actions are referenced by mutable major tags rather than immutable commit SHAs, including third-party Blacksmith actions. If any referenced action tag is retargeted or the action repository is compromised, attacker-controlled code can run with package write access or Docker registry credentials and publish a malicious web image.

**Recommendation:** Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

---

### Custom domains are globally reserved before ownership verification

- **File:** `crates/controlplane/src/domains/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 160, 161, 169, 172
- **Slug:** other-domain-squatting
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The domain create route requires a valid session and `Role::Member` in the workspace, then resolves the service under that workspace. It normalizes the requested hostname and calls `validate_hostname`, but that helper only enforces syntax such as label characters, length, and requiring a dot. The insertion into `service_domains` happens immediately after syntax validation, and the schema has a global `UNIQUE (hostname)` constraint. There is no TXT, CNAME, HTTP, ACME, or other ownership challenge before the global reservation is created. A member in one workspace can claim a hostname belonging to another tenant and cause later legitimate attempts to fail with `hostname already in use`. If DNS for that hostname already points at, or later points at, the attacker's managed node, the scheduler and agent Caddy route code will serve the attacker's service for that host. The primary guaranteed impact is cross-tenant domain squatting/denial of legitimate onboarding, with conditional traffic takeover.

create normalizes and syntax-validates the hostname, then inserts it into service_domains under a global UNIQUE(hostname) constraint. There is no DNS TXT/CNAME/HTTP challenge or other ownership proof before the hostname is reserved. Any authenticated workspace member can preemptively claim another tenant's domain and block the legitimate owner from adding it later; stale DNS or reused node IPs can turn this into traffic takeover if the hostname points at the attacker's node.

**Recommendation:** Add an ownership verification flow before globally reserving or activating a hostname. Use per-claim tokens with expiration, require DNS TXT/CNAME or HTTP challenge proof, and allow a verified owner to supersede unverified pending claims.

---

### Domain retry probe is DNS-rebinding prone

- **File:** `crates/controlplane/src/domains/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 279, 280
- **Slug:** ssrf
- **Confidence:** medium
- **Revalidation:** confirmed
- **Reasoning:** The retry route is reachable to `Role::Member` users for a scoped service domain and calls `domains::probe_one` synchronously after resetting the row to pending. `probe_one` resolves the stored hostname with `tokio::net::lookup_host`, checks that at least one returned address string equals the expected public node IP, and then calls `probe_hostname`. `probe_hostname` constructs `https://{hostname}` and lets `reqwest` perform its own connection resolution, so the checked DNS answer is not pinned to the outbound request. The code also does not reject loopback, private, link-local, or metadata ranges on either resolution. An attacker controlling DNS for a claimed hostname can return the expected node IP for the validation lookup and a private/internal address for the later HTTPS connection, causing the control plane to attempt a port-443 connection to that target. The impact is constrained by HTTPS, certificate validation, no redirects, and a five-second timeout, so this is best characterized as a limited SSRF/timing-or-error oracle rather than arbitrary internal HTTP response retrieval. The scheduled TLS refresh uses the same helper, and the retry endpoint gives a member a synchronous trigger.

retry lets a workspace member synchronously trigger domains::probe_one for a service domain. The probe helper first resolves the hostname and checks that one result equals the expected node IP, but then performs reqwest.get("https://{hostname}"), causing a second DNS resolution for the actual connection. An attacker-controlled domain can answer with the expected node IP for the validation lookup and then rebind to an internal/private address for the HTTPS request, turning the control plane into a limited port-443 SSRF and timing/error oracle.

**Recommendation:** Pin the validated resolution to the outbound request, or use a custom resolver that returns only the already-vetted IP. Reject loopback, private, link-local, and metadata ranges, and consider running the probe from the target node rather than from the control plane.

---

### Workspace monthly cost cap is configurable but unenforced

- **File:** `crates/controlplane/src/workspaces/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 219, 238, 257
- **Slug:** expensive-api-abuse
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The current update route accepts max_monthly_euro, only rejects negative values, and persists it to workspaces. A tree-wide search shows max_monthly_euro is otherwise only present in the workspace API shape, entity metadata, and migration, not in paid Hetzner operations. Scheduler provisioning reads hetzner_location, max_nodes, and scheduler_paused_until, then provisions after only a node-count cap. Manual node provisioning likewise selects max_nodes but not max_monthly_euro before calling the Hetzner provisioner. Volume creation authorizes a workspace member and then calls HetznerClient.create_volume with user-controlled size up to 10240 GB without budget projection. A workspace member can therefore create billable volumes, and a member can deploy resource-hungry services that trigger provisioning, without the configured euro cap stopping provider calls. The only mitigation I found is max_nodes, which limits node count but not node class cost and does not cover volumes. The current git history for the file has no later patch adding enforcement, so the finding remains real.

The API accepts and persists max_monthly_euro with only a non-negative validation, but the paid-resource paths reviewed in this codebase do not enforce it. Scheduler provisioning reads max_nodes, not max_monthly_euro, and volume creation calls the Hetzner API directly without checking the cap. A workspace member who can deploy services or create volumes can therefore drive billable Hetzner usage past the configured cost cap.

**Recommendation:** Enforce max_monthly_euro before every paid Hetzner operation, including scheduler provisioning, manual node provisioning, and volume creation. Compute projected monthly cost for current nodes and volumes, reject or pause work that exceeds the cap, and make the UI reflect the same enforcement model.

---

### Read-only users can reveal service environment variables

- **File:** `web/src/components/service-settings.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 302, 430, 433, 444, 447
- **Slug:** other-info-disclosure
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The backend ServiceSummary includes env_vars and deserializes it directly into the serialized response. The service show endpoint only calls membership::resolve and does not require Role::Member, so a viewer who is a workspace member can fetch a service and receive plaintext env_vars. In the frontend, ServicePage always runs serviceQuery and the Settings tab is always present; canDeploy is false for viewers because canWrite excludes only the viewer role. EnvVarsSection initializes rows from service.env_vars regardless of canManage, and EnvRowEditor passes row.value into EnvReferenceInput even when disabled. A disabled password input still contains the plaintext value in component state and the browser, and the reveal button itself is not disabled. A read-only viewer can therefore use the normal UI reveal control or inspect the service API response to read variables they cannot edit. I found no server-side redaction or role-specific response shape, and the checked file history still contains this behavior.

The settings component always hydrates rows from service.env_vars and renders the plaintext value into the input. canManage only disables editing; the reveal button is still active, and even a password input keeps the secret value in the DOM. The service page passes canManage=false for viewer/read-only roles, but still renders the Settings tab and this component. Since environment variables are treated as secrets by the UI and commonly hold credentials, a read-only workspace viewer can inspect values they should not be able to manage or retrieve.

**Recommendation:** Redact environment variable values server-side for users below the role allowed to manage secrets, and have the component render masked placeholders without plaintext values or reveal controls when canManage is false.

---

## HIGH_BUG (5)

### Prerelease tags publish latest container images

- **File:** `.github/workflows/release.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 45, 46, 71, 72, 73, 81, 82, 83
- **Slug:** other-release-tagging
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The release workflow triggers on all tags matching `v*`, including prerelease-style tags such as `v1.2.0-beta.1`. The release upload step marks a GitHub release as prerelease when `github.ref_name` contains `-`, but that condition is not applied to the image job. The image job always pushes both `${{ github.ref_name }}` and `latest` tags for `controlplane` and `agent`. There is no `if` condition, metadata rule, or stable-semver filter around the `latest` tag lines. As a result, a prerelease tag would publish prerelease images and overwrite the stable `latest` tags in GHCR. I checked the full workflow and searched for related gating; no hidden mitigation is present. The concrete failure mode is an operator creating a beta tag and environments that consume `:latest` unintentionally receiving prerelease code.

The workflow marks releases with hyphenated tag names as prereleases, but the image job always pushes `:latest` for every `v*` tag. A tag such as `v1.2.0-beta.1` would create a prerelease while still overwriting the stable `latest` controlplane and agent images, which can unintentionally roll prerelease code into environments that consume latest.

**Recommendation:** Only push `:latest` for stable release tags, for example by adding a condition that excludes prerelease tag names, or use metadata-action rules that gate latest on a stable semver pattern.

---

### Concurrent build status can overwrite cancellation

- **File:** `crates/controlplane/src/agent/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 741, 746, 771, 795
- **Slug:** other-race-condition
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** `build_status` fetches the build, verifies that `build.node_id` matches the reporting node, and then checks `is_terminal(&build.status)` before issuing its update. The actual `UPDATE builds` statement is only `WHERE id = $7`; it does not also require a non-terminal status or the expected node id. The cancel path in `builds::cancel` correctly uses `WHERE id = $2 AND status NOT IN ('succeeded','failed','cancelled')`, but that does not protect against a concurrent agent report that already passed the pre-check. If cancellation commits after the pre-check and before the agent update, the agent update can overwrite `cancelled` with `succeeded` or `failed`. The handler also ignores `rows_affected` and immediately executes terminal side effects. On success it updates the service image, flips the deployment back to pending, deletes allocations, and nudges the scheduler; on failure it marks the deployment errored. Because the check, update, and side effects are not conditional in one transaction, the cancellation guarantee is raceable.

build_status checks is_terminal before updating, but the UPDATE itself has only WHERE id = $7. If a user cancels a build after this pre-check but before the UPDATE executes, the agent's status report can overwrite the cancelled row with succeeded or failed and then run the succeeded/failed deployment side effects. This breaks the intended cancellation guarantee and can deploy a build the user already cancelled.

**Recommendation:** Make the build status UPDATE conditional on status NOT IN ('succeeded','failed','cancelled') and the expected node_id, check rows_affected before applying deployment/service side effects, and ideally wrap the update plus side effects in one transaction.

---

### Node delete can drop Driftbase state while leaving a live Hetzner VM

- **File:** `crates/controlplane/src/nodes/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 381, 393, 404
- **Slug:** other-orphaned-cloud-resource
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The delete route is admin-gated and workspace-scoped, so the issue is not authorization but provider-state handling. It decides to call Hetzner only when provider is hetzner, status is not terminated, and hetzner_server_id is present. If first_hetzner_token returns None, the code falls through and deletes the node row even though the provider/server-id fields indicate a potentially live VM. That missing-token state is reachable because admins can delete credentials. The second path is also present: hetzner_provisioner::terminate sets node status to terminated before calling delete_server, then returns an error if provider deletion fails. A retry of the route sees status terminated, skips the Hetzner call, and deletes the row, losing the only Driftbase pointer to the billable VM. Hetzner 404 idempotency only helps after a delete call is actually made; it does not mitigate the missing-token or tombstone retry paths. The current git history has no later patch changing this flow.

The delete route decides to call Hetzner only when the node is not `terminated` and has a server id. If no Hetzner credential is available, it falls through and deletes the node row even though the VM may still be live. A second failure path exists after `hetzner_provisioner::terminate` marks the row `terminated` before calling Hetzner: if the provider delete fails, a retry skips Hetzner because status is now `terminated` and deletes the row. Both paths can orphan a billable VM outside Driftbase management.

**Recommendation:** Do not delete a Hetzner node row while `hetzner_server_id` is present unless provider deletion has succeeded or returned not-found. Keep a retryable state for failed termination, retry tombstones with server ids, and return an error when credentials are unavailable instead of dropping the row.

---

### Volume error paths can orphan paid Hetzner volumes

- **File:** `crates/controlplane/src/volumes/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 118, 132, 140, 157, 161, 194
- **Slug:** other-provider-resource-orphan
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The create handler inserts a local creating row, then calls HetznerClient.create_volume. If the provider create succeeds but the DB update that stores hetzner_volume_id fails, the control plane has no persisted pointer to the real volume. If the ID update succeeds but wait_for_action or the final status update fails, the error handler still deletes the local volumes row. The inline comment explicitly acknowledges that creation may have succeeded and a dangling Hetzner volume may remain. There is no best-effort provider delete in that error branch. The shared delete_backing_volume_and_row helper also removes the local row when the workspace no longer has a Hetzner token, because provider cleanup is skipped; service deletion uses the same helper. A workspace member can create a paid volume, and transient DB/action failures or missing credentials can leave it unmanaged and billable. The current history still contains this behavior, so the finding is real.

The create handler calls Hetzner to create a real volume, then updates the DB and waits for the action. If any later step fails, including the DB update, action wait, or a transient control-plane error after Hetzner accepted the create, the cleanup only deletes the local volumes row and returns the error. That drops the only control-plane pointer to a billable provider resource. The delete path also delegates provider cleanup out of band, so the route can remove local state while provider cleanup is incomplete in related helper code. This can leave users paying for unmanaged volumes that cannot be deleted from the product.

**Recommendation:** Do not delete the local row after a provider-side create may have succeeded. Keep an errored/orphaned row with hetzner_volume_id for recovery, or track the created provider ID and best-effort delete it before removing local state. For deletes, only remove the DB row after provider deletion succeeds, or mark cleanup_required for later reconciliation.

---

### Volume attach and delete checks are TOCTOU-prone

- **File:** `crates/controlplane/src/volumes/routes.rs`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 182, 188, 194, 231, 237, 246, 250
- **Slug:** other-race-condition
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** remove fetches the volume, checks workspace ownership and attached_service_id, then later calls delete_backing_volume_and_row using that stale row. attach_to_service separately fetches the volume, checks workspace and status, validates the mount path, then updates by id only. There is no transaction, SELECT FOR UPDATE, conditional UPDATE predicate, deleting/attaching transition, or rows_affected check that proves the row is still in the checked state. The schema has a unique index on attached_service_id, which prevents two volumes from attaching to one service, but it does not stop the same volume row being overwritten from service A to service B. A concurrent delete can observe an unattached volume, a concurrent attach can bind it to a service, and the delete can still remove the backing provider volume and DB row. Two concurrent attaches to different services can both pass the available check and the last UPDATE wins, silently moving the volume. Because these rows represent persistent storage and provider resources, the stale checks can cause data loss or unexpected storage movement. The current git history has no patch adding atomic state transitions.

remove fetches a volume, checks that attached_service_id is empty, and later deletes the provider volume and row without locking or rechecking the row. attach_to_service similarly checks status/workspace on a fetched row, then updates by id only. A concurrent attach can run after remove has checked that the volume is unattached, after which remove can still delete the backing volume and DB row. Concurrent attaches can also overwrite each other's attached_service_id. This can wipe or move persistent storage based on stale authorization/state checks.

**Recommendation:** Use a transaction with SELECT FOR UPDATE or conditional UPDATE/DELETE predicates that include workspace_id, current status, and attached_service_id. Check rows_affected/RETURNING before making provider calls, and transition the row to a deleting/attaching state atomically before external side effects.

---

## BUG (3)

### Release matrix uses a runner label as a Rust target triple

- **File:** `.github/workflows/release.yml`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>, blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com>
- **Lines:** 18, 19, 20, 21, 28, 36, 40
- **Slug:** other-release-build-breakage
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The release matrix sets one `target` to `blacksmith-4vcpu-ubuntu-2404-arm`, and that value is passed directly to `dtolnay/rust-toolchain` as a target and to `cargo build --target`. The same value is also used in the artifact copy path `target/${{ matrix.target }}/release/driftbase-agent`. I searched the repository for a custom target specification, Cargo target config, or other alias for this name and found none. The only ARM-specific dependency installation condition checks for `matrix.target == 'aarch64-unknown-linux-gnu'`, so it will not run for the current ARM entry. The configured runner for that matrix entry is still `ubuntu-24.04`, so the suspicious value is not even being used as a runner label in the `runner` field. The current `rust-toolchain.toml` only selects stable with rustfmt and clippy, and does not define custom targets. The release build path is therefore broken for the ARM matrix entry, matching the finding.

The second agent release matrix entry sets `target` to `blacksmith-4vcpu-ubuntu-2404-arm`, which is not a Rust target triple. The aarch64 dependency installation condition checks for `aarch64-unknown-linux-gnu`, so it will never run for this matrix entry, and `cargo build --target ${{ matrix.target }}` will fail or produce no artifact at the expected target path.

**Recommendation:** Use `target: aarch64-unknown-linux-gnu` for the ARM build and put any runner label in the `runner` field. Keep the dependency-install condition aligned with the actual target value.

---

### DNS helper miscomputes record names for multi-label public suffixes

- **File:** `web/src/components/domains-section.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 621, 626, 662, 667, 679
- **Slug:** other-logic-bug
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The component uses dnsRecordName for the DNS preview and pending setup help, and useCloudflareDetection uses apexDomain for Cloudflare NS probing and the dashboard link. dnsRecordName splits on dots and returns all labels except the last two, while apexDomain returns only the last two labels. The backend hostname validator accepts api.example.co.uk because it only validates label syntax, length, and that the hostname contains a dot. For api.example.co.uk, the UI computes record name api.example and apex co.uk, when the intended zone is example.co.uk and the record name is api. That also makes Cloudflare detection query NS records for co.uk and builds a dashboard link for co.uk instead of the user's zone. I found no Public Suffix List aware dependency or alternate helper in the frontend. This is not a security issue, but it is a real setup logic bug that can lead users to create the wrong DNS record and leave activation failing. The current file history still has the same helper logic.

The DNS guidance assumes the registrable domain is always the last two labels. `dnsRecordName()` returns `parts.slice(0, parts.length - 2).join('.')`, and `apexDomain()` returns `parts.slice(-2).join('.')`. For a hostname like `api.example.co.uk`, the UI will show record name `api.example` and Cloudflare zone `co.uk`, instead of record name `api` and zone `example.co.uk`. This can lead users to create incorrect DNS records and leave domain activation failing. This is not a security issue, but it is a real setup logic bug.

**Recommendation:** Use a Public Suffix List aware parser, or have the backend return DNS setup hints based on a PSL-aware registrable-domain calculation.

---

### Template deploy follow-up calls use the uncanonicalized slug

- **File:** `web/src/routes/w.$workspaceSlug.projects.$projectSlug.templates.$templateId.tsx`
- **Recent committers:** Lasse <77295879+lassejlv@users.noreply.github.com>
- **Lines:** 128, 129, 152, 174, 187, 204, 218
- **Slug:** other-logic-bug
- **Confidence:** high
- **Revalidation:** confirmed
- **Reasoning:** The template form computes `trimmedSlug` for service creation, but the `attach` and `deploy` mutation hooks are created from the raw editable `slug` state. The backend `create` handler further canonicalizes the slug with `req.slug.trim().to_lowercase()` and returns the created `service.slug`. The attach and deploy hook mutation functions do not accept a service slug argument, so they keep using the raw state value in their URL. Backend follow-up lookups use exact slug matching in `resolve_service` and `deploy`; they do not trim or lowercase the path segment. If the user enters uppercase characters or surrounding whitespace, the service is created under the canonical lowercase slug while attach/deploy target the raw slug and return not found. For volume templates, the code can create both the service and the volume before attach fails, leaving partial resources. The final navigation uses `service.slug`, but only after the failing follow-up calls complete successfully, so it does not mitigate the issue.

The attach-volume and deploy mutations are created with the raw editable slug state, but service creation sends a trimmed slug and the backend canonicalizes it further by lowercasing before returning the created service. If a user edits the slug to include uppercase letters or surrounding whitespace, the service is created under the backend-canonical slug while the volume attach and deploy calls still target the raw slug, causing a 404 after partial resource creation. For volume templates this can leave a created service and an unattached volume even though the deploy flow reports failure.

**Recommendation:** Use the canonical `service.slug` returned by `createService.mutateAsync` for the attach and deploy requests, for example by making those mutations accept the service slug as an argument instead of closing over the editable slug state.

---

