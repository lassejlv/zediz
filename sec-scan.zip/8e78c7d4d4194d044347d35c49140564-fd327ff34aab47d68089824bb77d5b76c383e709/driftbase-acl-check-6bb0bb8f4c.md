# [HIGH] Viewers can stop or restart deployments by bypassing client-side controls

**File:** [`web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/routes/w.$workspaceSlug.projects.$projectSlug.$serviceSlug.tsx#L72-L207) (lines 72, 73, 75, 181, 182, 206, 207)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `acl-check`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The page hides Stop/Restart behind canWrite, but the mutation hooks call /deployments/:id/stop and /deployments/:id/restart directly with only a deployment id. Tracing those backend handlers shows both call deployments::authorize, whose query only checks that the caller is a workspace member; it does not require Role::Member or higher. A read-only viewer can obtain deployment ids from the allowed deployment list and POST to these endpoints to stop or restart workloads, causing service disruption.

## Recommendation

Enforce write authorization server-side for deployment stop/restart, for example with an authorize_member/authorize_write helper that checks the workspace role is at least Member. Keep the UI gate, but treat it only as presentation. Add regression tests for viewer denial on stop and restart.

## Revalidation

**Verdict:** true-positive

The page hides Stop and Restart behind `canWrite`, but the mutation hooks call `/deployments/:id/stop` and `/deployments/:id/restart` directly with only a deployment id. A viewer can obtain deployment ids because `list_deployments` for a service only requires `membership::resolve`. The backend `stop` and `restart` handlers call `deployments::authorize`, and that helper only verifies that the caller has any `workspace_members` row. It fetches the role but never parses or enforces `Role::Member`. The `stop` handler enqueues a stop command or marks an unplaced deployment stopped, while `restart` enqueues removal, resets the row to pending, deletes allocations, and nudges the scheduler. Because the server lacks the write-role check, a viewer can craft the POST requests even though the UI hides the buttons. This is an authorization bug with concrete availability impact.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
