# [HIGH] Viewer role can read service environment secrets

**File:** [`crates/controlplane/src/services/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/services/routes.rs#L55-L393) (lines 55, 164, 393)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `other-info-disclosure`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

ServiceSummary serializes env_vars, and both list and show only call membership::resolve, which allows any workspace role including viewer. A read-only invited viewer can therefore GET the service list or a specific service and receive full environment variable values, including generated database passwords and connection strings stored as service env vars. The UI role text describes viewers as read-only, but read-only access should not imply access to secret material.

## Recommendation

Split safe service metadata from sensitive configuration. Return env var keys or masked values to viewers, and require at least Role::Member or Role::Admin for endpoints that return full env var values.

## Revalidation

**Verdict:** true-positive

The service list and show handlers call `membership::resolve` but never call `membership::require`, so viewers are authorized for both endpoints. `SERVICE_COLUMNS` includes `env_vars`, `ServiceRow` reads it as JSON, and `ServiceSummary` serializes it as `pub env_vars: EnvVars` without role-based redaction. There is no alternate response type for viewers and no masking step based on `ctx.role`. These environment variables are user-controlled runtime secrets and templates include generated database passwords and database URLs, so a read-only viewer can receive high-value secret material. The separate variable reference endpoint mostly returns keys and expressions, but the main service summary returns full values. The UI disabling edits for viewers is not a backend mitigation because the raw API response already contains the secrets. I would rate this high rather than medium because it is a direct confidentiality break of application secrets for the lowest workspace role.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
