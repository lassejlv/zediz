# [BUG] DNS helper miscomputes record names for multi-label public suffixes

**File:** [`web/src/components/domains-section.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/components/domains-section.tsx#L621-L679) (lines 621, 626, 662, 667, 679)
**Project:** driftbase
**Severity:** BUG  •  **Confidence:** high  •  **Slug:** `other-logic-bug`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The DNS guidance assumes the registrable domain is always the last two labels. `dnsRecordName()` returns `parts.slice(0, parts.length - 2).join('.')`, and `apexDomain()` returns `parts.slice(-2).join('.')`. For a hostname like `api.example.co.uk`, the UI will show record name `api.example` and Cloudflare zone `co.uk`, instead of record name `api` and zone `example.co.uk`. This can lead users to create incorrect DNS records and leave domain activation failing. This is not a security issue, but it is a real setup logic bug.

## Recommendation

Use a Public Suffix List aware parser, or have the backend return DNS setup hints based on a PSL-aware registrable-domain calculation.

## Revalidation

**Verdict:** true-positive

The component uses dnsRecordName for the DNS preview and pending setup help, and useCloudflareDetection uses apexDomain for Cloudflare NS probing and the dashboard link. dnsRecordName splits on dots and returns all labels except the last two, while apexDomain returns only the last two labels. The backend hostname validator accepts api.example.co.uk because it only validates label syntax, length, and that the hostname contains a dot. For api.example.co.uk, the UI computes record name api.example and apex co.uk, when the intended zone is example.co.uk and the record name is api. That also makes Cloudflare detection query NS records for co.uk and builds a dashboard link for co.uk instead of the user's zone. I found no Public Suffix List aware dependency or alternate helper in the frontend. This is not a security issue, but it is a real setup logic bug that can lead users to create the wrong DNS record and leave activation failing. The current file history still has the same helper logic.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
