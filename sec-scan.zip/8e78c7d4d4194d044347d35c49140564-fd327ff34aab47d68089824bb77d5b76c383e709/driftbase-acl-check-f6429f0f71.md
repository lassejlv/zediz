# [HIGH] Workspace viewers can stop and restart deployments

**File:** [`crates/controlplane/src/deployments/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/deployments/routes.rs#L37-L120) (lines 37, 40, 77, 91, 110, 120)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `acl-check`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

`stop` and `restart` only call `deployments::authorize`, which the helper documents and implements as an at-least-viewer workspace membership check. These handlers then enqueue Stop/Remove commands, mutate deployment state, delete allocations, nudge scheduling, and in `restart` clear `scheduler_paused_until`. A read-only workspace viewer can therefore disrupt running services and trigger redeployment/provisioning actions.

## Recommendation

Resolve the deployment's workspace and require an appropriate role, likely `Role::Member` or `Role::Admin`, before mutating deployment state. Consider adding a dedicated `authorize_member`/`authorize_admin` helper for deployment actions.

## Revalidation

**Verdict:** true-positive

The `/deployments/:id/stop` and `/deployments/:id/restart` routes are mounted under `/api/v1` and require only `AuthUser`, which validates a normal user session. Both handlers then call `deployments::authorize`, whose implementation only joins `workspace_members` for the user and deployment and does not parse or require any minimum role. The helper comment explicitly says it enforces at least viewer access, and `membership::Role` ranks viewer as a valid workspace role. After that weak check, `stop` enqueues a Stop command or directly marks the deployment stopped and deletes allocations. `restart` enqueues Remove, resets the deployment to pending, clears node/private state, deletes allocations, clears `scheduler_paused_until`, and nudges the scheduler. The frontend may hide management controls for viewers, but the backend route itself accepts direct POSTs. A viewer who can see deployment IDs through workspace-readable service/deployment endpoints can disrupt running workloads, so this is exploitable as reported.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
