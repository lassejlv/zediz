# [HIGH_BUG] Volume attach and delete checks are TOCTOU-prone

**File:** [`crates/controlplane/src/volumes/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/volumes/routes.rs#L182-L250) (lines 182, 188, 194, 231, 237, 246, 250)
**Project:** driftbase
**Severity:** HIGH_BUG  •  **Confidence:** high  •  **Slug:** `other-race-condition`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

remove fetches a volume, checks that attached_service_id is empty, and later deletes the provider volume and row without locking or rechecking the row. attach_to_service similarly checks status/workspace on a fetched row, then updates by id only. A concurrent attach can run after remove has checked that the volume is unattached, after which remove can still delete the backing volume and DB row. Concurrent attaches can also overwrite each other's attached_service_id. This can wipe or move persistent storage based on stale authorization/state checks.

## Recommendation

Use a transaction with SELECT FOR UPDATE or conditional UPDATE/DELETE predicates that include workspace_id, current status, and attached_service_id. Check rows_affected/RETURNING before making provider calls, and transition the row to a deleting/attaching state atomically before external side effects.

## Revalidation

**Verdict:** true-positive

remove fetches the volume, checks workspace ownership and attached_service_id, then later calls delete_backing_volume_and_row using that stale row. attach_to_service separately fetches the volume, checks workspace and status, validates the mount path, then updates by id only. There is no transaction, SELECT FOR UPDATE, conditional UPDATE predicate, deleting/attaching transition, or rows_affected check that proves the row is still in the checked state. The schema has a unique index on attached_service_id, which prevents two volumes from attaching to one service, but it does not stop the same volume row being overwritten from service A to service B. A concurrent delete can observe an unattached volume, a concurrent attach can bind it to a service, and the delete can still remove the backing provider volume and DB row. Two concurrent attaches to different services can both pass the available check and the last UPDATE wins, silently moving the volume. Because these rows represent persistent storage and provider resources, the stale checks can cause data loss or unexpected storage movement. The current git history has no patch adding atomic state transitions.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
