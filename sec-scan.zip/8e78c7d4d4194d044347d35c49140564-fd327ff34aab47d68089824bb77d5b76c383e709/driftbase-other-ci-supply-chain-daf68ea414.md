# [MEDIUM] Mutable GitHub Action refs can publish compromised control plane images

**File:** [`.github/workflows/controlplane-image.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/controlplane-image.yml#L17-L48) (lines 17, 18, 19, 21, 23, 26, 28, 32, 34, 42, 47, 48)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-ci-supply-chain`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/controlplane. The actions are referenced by mutable major tags rather than immutable commit SHAs, including third-party Blacksmith actions. If any referenced action tag is retargeted or the action repository is compromised, attacker-controlled code can run with package write access or Docker registry credentials and publish a malicious control plane image.

## Recommendation

Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

## Revalidation

**Verdict:** true-positive

The control plane image workflow grants `packages: write`, logs in to GHCR with `${{ secrets.GITHUB_TOKEN }}`, and pushes `ghcr.io/driftbase/controlplane`. The job uses only mutable action refs, including the third-party Blacksmith setup and build-push actions. Any compromised or retagged referenced action can execute code in this job with package publishing permissions, and after the login step later action code can use the active Docker registry credentials. The vulnerable sink is the final `useblacksmith/build-push-action@v2` step with `push: true`, which controls the published multi-architecture image. The workflow is limited to pushes on `main` affecting relevant files or manual dispatch, but that only limits when the compromised action code runs. I read the complete workflow and checked recent history/status; the current version has not been patched with commit SHA pins. The concrete attack is action supply-chain compromise resulting in a malicious control plane image being pushed under the Driftbase GHCR namespace.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
