# [HIGH_BUG] Concurrent build status can overwrite cancellation

**File:** [`crates/controlplane/src/agent/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/agent/routes.rs#L741-L795) (lines 741, 746, 771, 795)
**Project:** driftbase
**Severity:** HIGH_BUG  •  **Confidence:** high  •  **Slug:** `other-race-condition`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

build_status checks is_terminal before updating, but the UPDATE itself has only WHERE id = $7. If a user cancels a build after this pre-check but before the UPDATE executes, the agent's status report can overwrite the cancelled row with succeeded or failed and then run the succeeded/failed deployment side effects. This breaks the intended cancellation guarantee and can deploy a build the user already cancelled.

## Recommendation

Make the build status UPDATE conditional on status NOT IN ('succeeded','failed','cancelled') and the expected node_id, check rows_affected before applying deployment/service side effects, and ideally wrap the update plus side effects in one transaction.

## Revalidation

**Verdict:** true-positive

`build_status` fetches the build, verifies that `build.node_id` matches the reporting node, and then checks `is_terminal(&build.status)` before issuing its update. The actual `UPDATE builds` statement is only `WHERE id = $7`; it does not also require a non-terminal status or the expected node id. The cancel path in `builds::cancel` correctly uses `WHERE id = $2 AND status NOT IN ('succeeded','failed','cancelled')`, but that does not protect against a concurrent agent report that already passed the pre-check. If cancellation commits after the pre-check and before the agent update, the agent update can overwrite `cancelled` with `succeeded` or `failed`. The handler also ignores `rows_affected` and immediately executes terminal side effects. On success it updates the service image, flips the deployment back to pending, deletes allocations, and nudges the scheduler; on failure it marks the deployment errored. Because the check, update, and side effects are not conditional in one transaction, the cancellation guarantee is raceable.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
