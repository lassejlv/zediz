# [HIGH] Read-only workspace viewers can receive service environment secrets

**File:** [`web/src/lib/types.ts`](https://github.com/lassejlv/driftbase/blob/main/web/src/lib/types.ts#L121) (lines 121)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `acl-check`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

ServiceSummary includes raw env_vars in the frontend API type at line 121. The backend ServiceSummary also serializes env_vars, and both service list/show routes only call membership::resolve, not membership::require with a write/admin role, before returning those summaries. The UI explicitly treats the viewer role as read-only, but the service settings view initializes its environment rows directly from service.env_vars and even lets the reveal button toggle password fields. A workspace viewer can therefore request /api/v1/workspaces/{slug}/projects/{project}/services or a service detail endpoint and recover container environment values such as generated Postgres passwords, database URLs, API tokens, or other application secrets.

## Recommendation

Do not include env_vars in the general ServiceSummary returned to all workspace members. Return redacted values or only keys for viewer/read-only responses, and expose plaintext environment values only through a dedicated endpoint guarded by at least Role::Member or preferably Role::Admin. Also disable or remove the reveal control for users who are not allowed to view secrets.

## Revalidation

**Verdict:** true-positive

`web/src/lib/types.ts` defines `ServiceSummary.env_vars` as a raw `Record<string, string>`, which matches the backend contract rather than a redacted or key-only representation. The frontend service queries fetch `ServiceSummary` from the list/show endpoints, and those backend endpoints authorize viewers via `membership::resolve` only. The service page computes `canManage` from `canWrite`, so viewers cannot submit edits through normal UI controls, but the data is already loaded into the page. `ServiceSettingsTab` initializes its environment rows directly from `service.env_vars`; the value input is disabled for viewers, but the reveal button itself is not disabled and the network response contains the plaintext values regardless. This file is not the root cause by itself, but it confirms the client-side API model expects full secret values for all consumers of `ServiceSummary`. A viewer can therefore receive generated Postgres passwords, connection strings, API tokens, or other environment secrets through the normal service API response.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
