# [HIGH] Fresh instances can be claimed by the first public signup

**File:** [`crates/controlplane/src/auth/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/auth/routes.rs#L104-L152) (lines 104, 117, 152)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `auth-bypass`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

/auth/signup is public and promotes the first account in an empty users table to approved platform admin, then immediately issues a session. There is no setup token, local-only restriction, or other installer proof. If the control plane is reachable before the real operator creates the first account, an unauthenticated attacker can become the platform admin and bootstrap their own workspace.

## Recommendation

Gate first-admin creation behind a one-time setup secret or out-of-band CLI/admin creation path. Keep public signup accounts pending until an already-established platform admin approves them.

## Revalidation

**Verdict:** true-positive

`/auth/signup` is public by design and takes no `AuthUser` or setup credential. The handler validates email/password and applies only per-email rate limiting, then takes an advisory lock and counts rows in `users`. If the count is zero, it inserts the new account with `status = 'approved'` and `is_platform_admin = true`. It then treats `is_first_user` as active and immediately creates a session cookie. There is no setup token, local-only restriction, deployment flag, or out-of-band installer proof in the route or surrounding router. The global router mounts `/api/v1/auth/signup` publicly, and CORS settings do not mitigate a direct network request. If a fresh control plane is reachable before the operator creates the first account, an unauthenticated attacker can become the platform admin and then create/manage workspaces.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
