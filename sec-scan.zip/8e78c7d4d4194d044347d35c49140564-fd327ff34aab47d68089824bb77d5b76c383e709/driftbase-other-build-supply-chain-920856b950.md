# [MEDIUM] Agent image build executes an unpinned remote installer

**File:** [`.github/workflows/agent-image.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/agent-image.yml#L42-L47) (lines 42, 45, 47)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-build-supply-chain`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

This workflow publishes the image built from Dockerfile.agent. That Dockerfile runs `curl -fsSL https://railpack.com/install.sh | bash` during the build without a version pin, checksum, or signature verification. A compromise of the installer endpoint or upstream distribution path would execute attacker-controlled code during the trusted image build and could backdoor the published agent image.

## Recommendation

Replace the curl-to-shell installer with a pinned release artifact verified by checksum/signature, or vendor a known-good binary into the build process.

## Revalidation

**Verdict:** true-positive

The agent image workflow builds with `file: Dockerfile.agent` and `push: true`, so the Dockerfile contents are part of the trusted published agent image path. In `Dockerfile.agent`, the runtime stage runs `curl -fsSL https://railpack.com/install.sh | bash -s -- -y -b /usr/local/bin` without a version pin, checksum, signature verification, or vendored artifact. That means the build executes whatever shell script the remote endpoint serves at build time. If the endpoint, CDN, DNS path, or upstream release process is compromised, attacker-controlled code runs during the image build and can modify the produced agent image before it is pushed to GHCR. This is not mitigated by Docker layer isolation because the script runs inside the build stage that becomes the runtime image containing `/usr/local/bin` contents. I also checked the release Dockerfile path separately; `docker/agent.Dockerfile` does not contain this installer, but this finding targets the branch image workflow, which still uses root `Dockerfile.agent`. The concrete attack is upstream installer compromise leading to a backdoored published `ghcr.io/driftbase/agent` image.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
