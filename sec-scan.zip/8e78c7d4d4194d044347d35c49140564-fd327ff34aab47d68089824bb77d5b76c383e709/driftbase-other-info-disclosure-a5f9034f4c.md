# [MEDIUM] Read-only users can reveal service environment variables

**File:** [`web/src/components/service-settings.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/components/service-settings.tsx#L302-L447) (lines 302, 430, 433, 444, 447)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-info-disclosure`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The settings component always hydrates rows from service.env_vars and renders the plaintext value into the input. canManage only disables editing; the reveal button is still active, and even a password input keeps the secret value in the DOM. The service page passes canManage=false for viewer/read-only roles, but still renders the Settings tab and this component. Since environment variables are treated as secrets by the UI and commonly hold credentials, a read-only workspace viewer can inspect values they should not be able to manage or retrieve.

## Recommendation

Redact environment variable values server-side for users below the role allowed to manage secrets, and have the component render masked placeholders without plaintext values or reveal controls when canManage is false.

## Revalidation

**Verdict:** true-positive

The backend ServiceSummary includes env_vars and deserializes it directly into the serialized response. The service show endpoint only calls membership::resolve and does not require Role::Member, so a viewer who is a workspace member can fetch a service and receive plaintext env_vars. In the frontend, ServicePage always runs serviceQuery and the Settings tab is always present; canDeploy is false for viewers because canWrite excludes only the viewer role. EnvVarsSection initializes rows from service.env_vars regardless of canManage, and EnvRowEditor passes row.value into EnvReferenceInput even when disabled. A disabled password input still contains the plaintext value in component state and the browser, and the reveal button itself is not disabled. A read-only viewer can therefore use the normal UI reveal control or inspect the service API response to read variables they cannot edit. I found no server-side redaction or role-specific response shape, and the checked file history still contains this behavior.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
