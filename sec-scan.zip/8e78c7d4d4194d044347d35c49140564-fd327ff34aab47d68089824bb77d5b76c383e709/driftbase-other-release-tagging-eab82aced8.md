# [HIGH_BUG] Prerelease tags publish latest container images

**File:** [`.github/workflows/release.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/release.yml#L45-L83) (lines 45, 46, 71, 72, 73, 81, 82, 83)
**Project:** driftbase
**Severity:** HIGH_BUG  •  **Confidence:** high  •  **Slug:** `other-release-tagging`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The workflow marks releases with hyphenated tag names as prereleases, but the image job always pushes `:latest` for every `v*` tag. A tag such as `v1.2.0-beta.1` would create a prerelease while still overwriting the stable `latest` controlplane and agent images, which can unintentionally roll prerelease code into environments that consume latest.

## Recommendation

Only push `:latest` for stable release tags, for example by adding a condition that excludes prerelease tag names, or use metadata-action rules that gate latest on a stable semver pattern.

## Revalidation

**Verdict:** true-positive

The release workflow triggers on all tags matching `v*`, including prerelease-style tags such as `v1.2.0-beta.1`. The release upload step marks a GitHub release as prerelease when `github.ref_name` contains `-`, but that condition is not applied to the image job. The image job always pushes both `${{ github.ref_name }}` and `latest` tags for `controlplane` and `agent`. There is no `if` condition, metadata rule, or stable-semver filter around the `latest` tag lines. As a result, a prerelease tag would publish prerelease images and overwrite the stable `latest` tags in GHCR. I checked the full workflow and searched for related gating; no hidden mitigation is present. The concrete failure mode is an operator creating a beta tag and environments that consume `:latest` unintentionally receiving prerelease code.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
