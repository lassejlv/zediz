# [MEDIUM] Custom domains are globally reserved before ownership verification

**File:** [`crates/controlplane/src/domains/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/domains/routes.rs#L160-L172) (lines 160, 161, 169, 172)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-domain-squatting`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

create normalizes and syntax-validates the hostname, then inserts it into service_domains under a global UNIQUE(hostname) constraint. There is no DNS TXT/CNAME/HTTP challenge or other ownership proof before the hostname is reserved. Any authenticated workspace member can preemptively claim another tenant's domain and block the legitimate owner from adding it later; stale DNS or reused node IPs can turn this into traffic takeover if the hostname points at the attacker's node.

## Recommendation

Add an ownership verification flow before globally reserving or activating a hostname. Use per-claim tokens with expiration, require DNS TXT/CNAME or HTTP challenge proof, and allow a verified owner to supersede unverified pending claims.

## Revalidation

**Verdict:** true-positive

The domain create route requires a valid session and `Role::Member` in the workspace, then resolves the service under that workspace. It normalizes the requested hostname and calls `validate_hostname`, but that helper only enforces syntax such as label characters, length, and requiring a dot. The insertion into `service_domains` happens immediately after syntax validation, and the schema has a global `UNIQUE (hostname)` constraint. There is no TXT, CNAME, HTTP, ACME, or other ownership challenge before the global reservation is created. A member in one workspace can claim a hostname belonging to another tenant and cause later legitimate attempts to fail with `hostname already in use`. If DNS for that hostname already points at, or later points at, the attacker's managed node, the scheduler and agent Caddy route code will serve the attacker's service for that host. The primary guaranteed impact is cross-tenant domain squatting/denial of legitimate onboarding, with conditional traffic takeover.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
