# [BUG] Release matrix uses a runner label as a Rust target triple

**File:** [`.github/workflows/release.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/release.yml#L18-L40) (lines 18, 19, 20, 21, 28, 36, 40)
**Project:** driftbase
**Severity:** BUG  •  **Confidence:** high  •  **Slug:** `other-release-build-breakage`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The second agent release matrix entry sets `target` to `blacksmith-4vcpu-ubuntu-2404-arm`, which is not a Rust target triple. The aarch64 dependency installation condition checks for `aarch64-unknown-linux-gnu`, so it will never run for this matrix entry, and `cargo build --target ${{ matrix.target }}` will fail or produce no artifact at the expected target path.

## Recommendation

Use `target: aarch64-unknown-linux-gnu` for the ARM build and put any runner label in the `runner` field. Keep the dependency-install condition aligned with the actual target value.

## Revalidation

**Verdict:** true-positive

The release matrix sets one `target` to `blacksmith-4vcpu-ubuntu-2404-arm`, and that value is passed directly to `dtolnay/rust-toolchain` as a target and to `cargo build --target`. The same value is also used in the artifact copy path `target/${{ matrix.target }}/release/driftbase-agent`. I searched the repository for a custom target specification, Cargo target config, or other alias for this name and found none. The only ARM-specific dependency installation condition checks for `matrix.target == 'aarch64-unknown-linux-gnu'`, so it will not run for the current ARM entry. The configured runner for that matrix entry is still `ubuntu-24.04`, so the suspicious value is not even being used as a runner label in the `runner` field. The current `rust-toolchain.toml` only selects stable with rustfmt and clippy, and does not define custom targets. The release build path is therefore broken for the ARM matrix entry, matching the finding.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
