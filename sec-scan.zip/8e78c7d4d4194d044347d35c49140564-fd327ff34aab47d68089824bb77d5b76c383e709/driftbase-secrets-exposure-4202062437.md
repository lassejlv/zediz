# [HIGH] Members can exfiltrate GitHub PATs through arbitrary git remotes

**File:** [`crates/controlplane/src/services/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/services/routes.rs#L67-L573) (lines 67, 319, 340, 449, 502, 508, 573)
**Project:** driftbase
**Severity:** HIGH  •  **Confidence:** high  •  **Slug:** `secrets-exposure`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The service create/update paths accept both an arbitrary git_repo and a github_credential_id from request JSON while requiring only Role::Member. The response model also exposes github_credential_id, so a non-admin member can learn a PAT credential ID from an existing service, update that service to point git_repo at an attacker-controlled HTTPS remote, and deploy. Downstream code validates only that the credential is a github_pat in the same workspace, then hydrates the PAT into the agent build payload; the agent's git credential helper supplies that PAT for any HTTPS clone URL and only refuses plain http://. This turns deploy permission into plaintext GitHub PAT exfiltration.

## Recommendation

Validate credential use at create/update time and bind GitHub PAT credentials to allowed GitHub hosts/repos before deployment. Do not expose credential IDs to non-admins, require admin approval or an explicit usable-by-members policy for PAT-backed builds, and scope the git credential helper to the allowed GitHub origin instead of any HTTPS URL.

## Revalidation

**Verdict:** true-positive

Service create and update require only `Role::Member`, and the git-source fields accept `git_repo` plus `github_credential_id` directly from request JSON. The update path does not validate that a supplied credential is a GitHub PAT, that it is intended for the repository, or that the repository is on GitHub; it only stores the field. `ServiceSummary` includes `github_credential_id`, and service list/show are available to any workspace member, so a non-admin member can learn the PAT credential id from an existing PAT-backed service. The scheduler later validates only that the credential exists in the same workspace and has kind `github_pat`, then the agent command hydration replaces the credential id with the plaintext PAT. On the agent, `git clone` installs a credential helper that returns `x-access-token` and `$DRIFTBASE_GIT_TOKEN` for credential prompts, and the only host-related guard is refusing plain `http://`. An attacker with member access can point an existing git service at an attacker-controlled HTTPS remote and deploy; the remote can challenge for credentials and receive the PAT over HTTPS. The same-workspace scope prevents cross-tenant credential theft, but it does not prevent member-level misuse of an admin-added PAT.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
