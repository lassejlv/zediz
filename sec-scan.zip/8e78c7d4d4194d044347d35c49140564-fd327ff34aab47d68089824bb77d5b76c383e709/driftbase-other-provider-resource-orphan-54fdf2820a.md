# [HIGH_BUG] Volume error paths can orphan paid Hetzner volumes

**File:** [`crates/controlplane/src/volumes/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/volumes/routes.rs#L118-L194) (lines 118, 132, 140, 157, 161, 194)
**Project:** driftbase
**Severity:** HIGH_BUG  •  **Confidence:** high  •  **Slug:** `other-provider-resource-orphan`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The create handler calls Hetzner to create a real volume, then updates the DB and waits for the action. If any later step fails, including the DB update, action wait, or a transient control-plane error after Hetzner accepted the create, the cleanup only deletes the local volumes row and returns the error. That drops the only control-plane pointer to a billable provider resource. The delete path also delegates provider cleanup out of band, so the route can remove local state while provider cleanup is incomplete in related helper code. This can leave users paying for unmanaged volumes that cannot be deleted from the product.

## Recommendation

Do not delete the local row after a provider-side create may have succeeded. Keep an errored/orphaned row with hetzner_volume_id for recovery, or track the created provider ID and best-effort delete it before removing local state. For deletes, only remove the DB row after provider deletion succeeds, or mark cleanup_required for later reconciliation.

## Revalidation

**Verdict:** true-positive

The create handler inserts a local creating row, then calls HetznerClient.create_volume. If the provider create succeeds but the DB update that stores hetzner_volume_id fails, the control plane has no persisted pointer to the real volume. If the ID update succeeds but wait_for_action or the final status update fails, the error handler still deletes the local volumes row. The inline comment explicitly acknowledges that creation may have succeeded and a dangling Hetzner volume may remain. There is no best-effort provider delete in that error branch. The shared delete_backing_volume_and_row helper also removes the local row when the workspace no longer has a Hetzner token, because provider cleanup is skipped; service deletion uses the same helper. A workspace member can create a paid volume, and transient DB/action failures or missing credentials can leave it unmanaged and billable. The current history still contains this behavior, so the finding is real.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
