# [MEDIUM] Mutable GitHub Action refs can publish compromised web images

**File:** [`.github/workflows/web-image.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/web-image.yml#L16-L47) (lines 16, 17, 18, 20, 22, 25, 27, 31, 33, 41, 46, 47)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-ci-supply-chain`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The workflow grants package publishing rights and logs in to GHCR with GITHUB_TOKEN before pushing ghcr.io/driftbase/web. The actions are referenced by mutable major tags rather than immutable commit SHAs, including third-party Blacksmith actions. If any referenced action tag is retargeted or the action repository is compromised, attacker-controlled code can run with package write access or Docker registry credentials and publish a malicious web image.

## Recommendation

Pin all actions to full-length commit SHAs, especially third-party actions. Keep the job permissions at least-privilege and periodically review/renew pinned action SHAs.

## Revalidation

**Verdict:** true-positive

The web image workflow grants `packages: write`, logs in to GHCR using `${{ secrets.GITHUB_TOKEN }}`, and pushes `ghcr.io/driftbase/web`. It references `actions/checkout@v4`, `docker/setup-qemu-action@v3`, `useblacksmith/setup-docker-builder@v1`, `docker/login-action@v3`, `docker/metadata-action@v5`, and `useblacksmith/build-push-action@v2` by mutable tags rather than full commit SHAs. A compromised or retagged action can execute code in the workflow with package write permission, and after the login step can use the active Docker registry credentials. The final Blacksmith build-push step controls the image content and performs the push with `push: true`. The trigger is limited to `main` pushes affecting web image inputs or manual dispatch, but that still leaves the supply-chain path exploitable on legitimate runs. I read the complete workflow and checked current history/status; there is no pinning or alternate mitigation in the current file. The concrete attack is publishing a malicious web image under the project GHCR namespace through a compromised mutable action.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
