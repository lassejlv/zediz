# [MEDIUM] Mutable release actions run with release and package publishing privileges

**File:** [`.github/workflows/release.yml`](https://github.com/lassejlv/driftbase/blob/main/.github/workflows/release.yml#L8-L75) (lines 8, 9, 23, 24, 32, 42, 51, 52, 53, 55, 56, 58, 59, 63, 65, 75)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** high  •  **Slug:** `other-ci-supply-chain`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The release workflow uses mutable action refs while granting contents: write for release creation and packages: write for image publishing. Third-party actions such as dtolnay/rust-toolchain@stable, Swatinem/rust-cache@v2, softprops/action-gh-release@v2, and useblacksmith/*@v1/v2 can execute in jobs that publish release artifacts or container images. A compromised or retagged action could replace release binaries or publish malicious GHCR images under the project namespace.

## Recommendation

Pin every action to a full commit SHA and review the pinned SHAs before updates. Split permissions by job and step where possible so actions that do not need write access do not receive it.

## Revalidation

**Verdict:** true-positive

The release workflow has top-level `contents: write`, so the agent release job's mutable actions run in a job that can create or modify releases. That job uses mutable refs for `actions/checkout@v4`, `dtolnay/rust-toolchain@stable`, `Swatinem/rust-cache@v2`, and `softprops/action-gh-release@v2`, then uploads release artifacts. The images job narrows contents to read but grants `packages: write`, logs in to GHCR, and uses mutable Docker and Blacksmith actions before pushing release images. A compromised or retagged action in either job can alter uploaded binaries, create or modify release assets, or publish malicious images depending on which job it runs in. The trigger is tag push matching `v*`, so exploitation requires a release workflow run plus action supply-chain compromise. I read the entire workflow and checked current history/status; there is no full-SHA pinning or permission isolation that would prevent this. The concrete attack is a malicious action replacing release binaries or pushing compromised `controlplane` and `agent` images during a tagged release.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-11)
- blacksmith-sh[bot] <157653362+blacksmith-sh[bot]@users.noreply.github.com> (2026-05-11)
