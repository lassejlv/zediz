# [BUG] Template deploy follow-up calls use the uncanonicalized slug

**File:** [`web/src/routes/w.$workspaceSlug.projects.$projectSlug.templates.$templateId.tsx`](https://github.com/lassejlv/driftbase/blob/main/web/src/routes/w.$workspaceSlug.projects.$projectSlug.templates.$templateId.tsx#L128-L218) (lines 128, 129, 152, 174, 187, 204, 218)
**Project:** driftbase
**Severity:** BUG  •  **Confidence:** high  •  **Slug:** `other-logic-bug`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

The attach-volume and deploy mutations are created with the raw editable slug state, but service creation sends a trimmed slug and the backend canonicalizes it further by lowercasing before returning the created service. If a user edits the slug to include uppercase letters or surrounding whitespace, the service is created under the backend-canonical slug while the volume attach and deploy calls still target the raw slug, causing a 404 after partial resource creation. For volume templates this can leave a created service and an unattached volume even though the deploy flow reports failure.

## Recommendation

Use the canonical `service.slug` returned by `createService.mutateAsync` for the attach and deploy requests, for example by making those mutations accept the service slug as an argument instead of closing over the editable slug state.

## Revalidation

**Verdict:** true-positive

The template form computes `trimmedSlug` for service creation, but the `attach` and `deploy` mutation hooks are created from the raw editable `slug` state. The backend `create` handler further canonicalizes the slug with `req.slug.trim().to_lowercase()` and returns the created `service.slug`. The attach and deploy hook mutation functions do not accept a service slug argument, so they keep using the raw state value in their URL. Backend follow-up lookups use exact slug matching in `resolve_service` and `deploy`; they do not trim or lowercase the path segment. If the user enters uppercase characters or surrounding whitespace, the service is created under the canonical lowercase slug while attach/deploy target the raw slug and return not found. For volume templates, the code can create both the service and the volume before attach fails, leaving partial resources. The final navigation uses `service.slug`, but only after the failing follow-up calls complete successfully, so it does not mitigate the issue.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-04-18)
