# [MEDIUM] Domain retry probe is DNS-rebinding prone

**File:** [`crates/controlplane/src/domains/routes.rs`](https://github.com/lassejlv/driftbase/blob/main/crates/controlplane/src/domains/routes.rs#L279-L280) (lines 279, 280)
**Project:** driftbase
**Severity:** MEDIUM  •  **Confidence:** medium  •  **Slug:** `ssrf`

## Owners

**Suggested assignee:** `77295879+lassejlv@users.noreply.github.com` _(via last-committer)_

## Finding

retry lets a workspace member synchronously trigger domains::probe_one for a service domain. The probe helper first resolves the hostname and checks that one result equals the expected node IP, but then performs reqwest.get("https://{hostname}"), causing a second DNS resolution for the actual connection. An attacker-controlled domain can answer with the expected node IP for the validation lookup and then rebind to an internal/private address for the HTTPS request, turning the control plane into a limited port-443 SSRF and timing/error oracle.

## Recommendation

Pin the validated resolution to the outbound request, or use a custom resolver that returns only the already-vetted IP. Reject loopback, private, link-local, and metadata ranges, and consider running the probe from the target node rather than from the control plane.

## Revalidation

**Verdict:** true-positive

The retry route is reachable to `Role::Member` users for a scoped service domain and calls `domains::probe_one` synchronously after resetting the row to pending. `probe_one` resolves the stored hostname with `tokio::net::lookup_host`, checks that at least one returned address string equals the expected public node IP, and then calls `probe_hostname`. `probe_hostname` constructs `https://{hostname}` and lets `reqwest` perform its own connection resolution, so the checked DNS answer is not pinned to the outbound request. The code also does not reject loopback, private, link-local, or metadata ranges on either resolution. An attacker controlling DNS for a claimed hostname can return the expected node IP for the validation lookup and a private/internal address for the later HTTPS connection, causing the control plane to attempt a port-443 connection to that target. The impact is constrained by HTTPS, certificate validation, no redirects, and a five-second timeout, so this is best characterized as a limited SSRF/timing-or-error oracle rather than arbitrary internal HTTP response retrieval. The scheduled TLS refresh uses the same helper, and the retry endpoint gives a member a synchronous trigger.

## Recent committers (`git log`)

- Lasse <77295879+lassejlv@users.noreply.github.com> (2026-05-10)
